"""1. Write a Python program to calculate the length of a given string.
    Data:
        "Baskar\""""

# Data = "Baskar"
# length = len(Data)
# print(length)

'''2. Write a Python program to remove the character of the nth index from a given string. 
    Data:
        "Python"
    Expected Output:
        ython
        Pyton
        Pytho'''

# def remove_char_at_index(s,n):
#     if n < 0 or n >= len(s):
#         return s # return the original string if the index is out of range
#     return s[:n] + s[n+1:]
#
# input_string =input("Enter the string: ")
# index = int(input("Enter the index that needs to be removed: "))
# res = remove_char_at_index(input_string,index)
# print("After removing the particular index at", index,":",res)

'''3. Write a Python program to interchange the first and last character of a given string.
    Data:
        'abcd'
        '12345'
    Expected Output:
        'dbca'
        52341'''

# def swap_first_last(s):
#     if len(s) <= 1:
#         return s
#     return s[-1] + s[1:-1] + s[0]

# input_string =input("Enter the string: ")
# answer = swap_first_last(input_string)
# print("After swapping the first and last character in the string then the updated value string is: ",answer)

'''4. Write a Python program to remove the values of the odd index from a given string.
    Data:
        'abcdef'
        'python'
    Expected Output:
        ace
        pto '''

# def remove_odd_index(s):
#     return s[::2]
#
# string = input("Enter the string:")
# result = remove_odd_index(string)
# print("String after removing odd index characters:",result)

'''5. Write a Python program to get input from the user and print the input back in uppercase.
    Data:
        Whats your favourite language: Tamil
    Expected Output:
        My favourite language is  TAMIL
        My favourite language is  tamil '''

# lang = input("Whats your favourite language: ")
# res = lang.upper()
# print(f"My favourite language is {res}")

'''6. Write a Python program that accepts a comma separated sequence of words as input and print only the unique strings in sorted.
    Data:
        Words : red, white, black, red, green, black
    Expected Output:
        black, green, red, white,red '''

# def unique_sorted_words(input_str):
#     words = input_str.split(",")
#     unique_words = sorted(set(words))
#     return ",".join(unique_words)
#
# data = input("Enter the data: ")
# output= unique_sorted_words(data)
# print("The output is:",output)

'''8. Write a Python function to insert the second string in the middle of a first string.
    Data:
        ('[[]]', 'Python')
        ('{{}}', 'PHP')
    Expected Output:
        [[Python]]
        {{PHP}}'''

# def insert_the_string(string1,string2):
#     middle_index = len(string1) // 2
#     result_string = string1[:middle_index] + string2 + string1[middle_index:]
#     return result_string
#
# first_string = input("Enter the string1: ")
# second_string = input("Enter the string2: ")
# output = insert_the_string(first_string,second_string)
# print("after instering it to the middle:",output)

'''9. Write a Python function to get a string made of 4 copies of the last two characters of a specified string 
    (length must be at least 2).
    Data:
        'Python'
    Expected Output:
        onononon '''

# def four_copies(str):
#     if len(str) < 2:
#         print("Length of the string must be atleast 2")
#
#     last_two = str[-2:]
#     return last_two * 4
# input_string = input("Enter the string: ")
# result = four_copies(input_string)
# print("The result is: ",result)

''' 10. Write a Python function to get a string made of its first three characters of a specified string. 
    If the length of the string is less than 3 then return the original string.
    Data:
        'ipy'
        'python'
    Expected Output:
        ipy
        pyt '''
# def first_three_char(str):
#     if len(str) < 3:
#         return str
#
#     first_three = str[:3]
#     return first_three
#
# input_string = input("Enter the string: ")
# result = first_three_char(input_string)
# print("The result is: ",result)

'''11. Write a Python function to reverse a string if its length is a multiple of 4.
    Data:
        'abcd'
        'python'
    Expected Output:
        dcba
        python '''

# def reverse_string(str):
#     if len(str) % 4 == 0:
#         return str[::-1]
#     else:
#         return str
#
# input_string = input("Enter the string: ")
# res = reverse_string(input_string)
# print("The expected output is :",res)



'''12. Write a Python program to get the last part of a string before a specified character.
    Data:
        str1 = 'https://www.aidinasaur.com/python-exercises/string'
    Expected Output:
        https://www.aidinasaur.com/python-exercises
        https://www.aidinasaur.com/python '''



'''13. Write a Python program to sort a string lexicographically.
    Data:
        aidinasaur
    Expected Output: 
        ['a', 'a', 'a', 'd', 'i', 'i', 'n', 'r', 's', 'u']'''

# data = "aidinasaur"
# sorted_char = sorted(data)
# print(sorted_char)


'''14. Write a Python program to remove a newline in Python.
    Data:
        'Python Exercises\n'
    Expected Output: 
        Python Exercises

        Python Exercises'''

# Data = 'Python Exercises\n'
# output = Data.replace('\n', ' ')
# print(output)
# print()
# print(output)



'''15. Write a Python program to check whether a string starts with specified character.
    Data:
        aidinasaur.com
    Expected Output:
        True'''



'''16. Write a Python program to count the number of occurrences of a substring in a string.
    Data:
        "Word to publish Word docs as web pages"
        count = "word"
    Expected Output:
        2'''

# def count_substring(input_string, sub_string):
#     count = input_string.count(sub_string)
#     return count
#
# data = input("Enter the input string: ").lower()
# sub_strings = input("Enter the sub string: ")
# res = count_substring(data, sub_strings)
# print(res)

'''17. Write a Python program to reverse a string.
    Data:
        "abcdef"
        "Python Exercises."
    Expected Output:
        fedcba
        .sesicrexE nohtyP'''

# def reverse_string(s):
#     return s[::-1]
#
# strings = input("Enter the string: ")
# res = reverse_string(strings)
# print("The reversed string is: ",res)

'''18. Write a Python program to lowercase first n characters in a string.
    Data:
        "AIDINASAUR.COM"
    Expected Output:  
        aidiNASAUR.COM'''

# def lower_first_n_characters(data, n):
#     result = data[:n].lower() + data[n:]
#     return result
#
# Data = input("Enter the string: ")
# num = int(input("Enter the n characters: "))
# res = lower_first_n_characters(Data,num)
# print(res)


'''19. Write a Python program to swap comma and dot in a string.
    Data:
        "32.054,23"
    Expected Output:
        "32,054.23"'''

# def swap(str1):
#     str1 = str1.replace('.', '@')
#     str1 = str1.replace('.', ',')
#     str1 = str1.replace('@','.')
#     print(str1)
#
# String = "32,054.23"
# swap(String)



'''20. Write a Python program to count and display the vowels of a given text.
    Data:
        "AIDINASAUR.COM"
    Expected Output:
        7
        ['A', 'I', 'I', 'A', 'A', 'U', 'O']'''

# def count_vowels(text):
#     vowels = "aeiouAEIOU"
#     vowel_list = []
#     for ch in text:
#         if ch in vowels:
#             vowel_list.append(ch)
#
#     count = len(vowel_list)
#     print(count)
#     print(vowel_list)
# Data = "AIDINASAUR.COM"
# count_vowels(Data)















