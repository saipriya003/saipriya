'''1. Write a Python program to convert and print the given list into a set.
    Data:
        x = [1,2,3,4]
    Expected Output:
        x = {1,2,3,4}'''
from linecache import clearcache

# x = [1, 2, 3, 4]
# my_set = set(x)
# print(my_set)

'''2.Write a Python program to find the length of a given set.
    Data:
        x = {4,5,6,7,9,2}
    Expected Output:
        6'''

# x = {4, 5, 6, 7, 9, 2}
# length = len(x)
# print(length)


'''3. Write a Python program to create a shallow copy of sets. 
    Data:
        a = ["Boss","Siva"]
    Expected Output:
        {"Boss","Siva"}'''

# a = ["Boss","Siva"]
# my_set = set(a)
# shallow_copy = my_set.copy()
# print(shallow_copy)


'''4. Write a Python program to remove an element from the given set using discard().
    Data:
        x= {0,1,2,3,4,5}
    Expected Output:
        {0, 1, 2, 4, 5}'''

# x = {0, 1, 2, 3, 4, 5}
# x.discard(3)
# print(x)


'''5. Write a Python program to add elements to a given set.
    Data:
        {"Boss"}
    Expected Output:
        {"Boss", "Siva", "Suresh"}'''

# x = {"Boss"}
# x.add("Siva")
# x.add("Suresh")
# print(x)

'''6. Write a Python program to remove an element from the given set using pop().
    Data:
        x = {1,2,3,4,5,6}
    Expected Output:
        {1, 2, 3, 4}'''

# x = {1,2,3,4,5,6}
# x.pop()
# x.pop()
# print(x)

'''7. Write a Python program to print each elements of a given set using for loop.
    Data:
        x = {1, 2, 3, 4, 5}
    Expected Output:
        1
        2
        3
        4
        5'''

# x = {1, 2, 3, 4, 5}
# for i in x:
#     print(i)

'''8. Write a Python program to print the intersection of two given sets. 
   Data:
        x = {"boss", "karthi"}
        y = {"karthi", "siva"}
    Expected Output:
        {'karthi'}'''

# x = {"boss", "karthi"}
# y = {"karthi", "siva"}
# print(x & y)

'''9. Write a Python program to print the union of two given sets. 
    Data:
        x = {"boss", "karthi"}
        y = {"karthi", "siva"}
    Expected Output:
        {'boss', 'siva', 'karthi'}'''

# x = {"boss", "karthi"}
# y = {"karthi", "siva"}
# print(x | y)


'''10. Write a Python program to print the symmetric difference between two given sets. 
    Data:
        x = {"boss","karthi"}
        y = {"karthi","siva"}
    Expected Output:
        {'boss', 'siva'}'''

# x = {"boss", "karthi"}
# y = {"karthi", "siva"}
# print(x ^ y)

'''11. Write a Python program to clear a given set.
    Data:
        x ={"Kutta", "Puppy"}
    Expected Output:
        The set x has elements : {'Puppy', 'Kutta'}
        After clearing the set x : set()'''

# x ={"Kutta", "Puppy"}
# print(f"The set x has elements : {x}")
# x.clear()
# print(f"After clearing the set x: {x}")

'''12. Write a Python program to print the maximum value from a given set. 
    Data:
        x = {23, 45, 12, 56, 87}
    Expected Output:
        87'''

# x = {23, 45, 12, 56, 87}
# max_val = max(x)
# print(max_val)

'''13. Write a Python program to print the minimum value from a given set. 
    Data:
        x = {23, 56, 2, 3, 78, 6}
    Expected Output:
        2'''

# x = {23, 56, 2, 3, 78, 6}
# min_val = min(x)
# print(min_val)

'''14. Write a Python program to remove the intersection of a 2nd set from the 1st set using difference_update().
    Data:
        x = {1, 2, 3, 4, 5}
        y = {4, 5, 6, 7, 8}
    Expected Output:
        {1, 2, 3}'''

# x = {1, 2, 3, 4, 5}
# y = {4, 5, 6, 7, 8}
# x.difference_update(y)
# print(x)

'''15. Write a Python program to update the 1st set with the intersection elements from another set using intersection_update().
    Data:
        x = {"apple", "banana", "cherry"}
        y = {"google", "microsoft", "apple"}
    Expected Output:
        {"apple"}'''

# x = {"apple", "banana", "cherry"}
# y = {"google", "microsoft", "apple"}
# x.intersection_update(y)
# print(x)

'''16. Write a Python program to zip two sets into a list.
    Data:
        {1, 2, 3},{"a", "b", "c"}
    Expected Output:
        [(1, 'c'),(2, 'b'),(3, 'a')]'''

# set1 = {1, 2, 3}
# set2 = {"a", "b", "c"}
# zipped_list = list(zip(set1,set2))
# print(zipped_list)



'''17. Write a Python program to convert a list into a set.
    Data:
        x = [5,3,4,1,2]
    Expected Output:
        {1,2,3,4,5}'''

# x = [5,3,4,1,2]
# my_set = set(x)
# print(my_set)

'''18. Write a python program to check if a set is a subset of another set using comparison operator. Return True if yes, False if not.
    Data:
        x = {"1", "2"}
        y = {"1", "2", "3"}
    Expected Output:
        True
        False'''

# x = {"1", "2"}
# y = {"1", "2", "3"}
# if x <= y: #set is a subset of another set
#     print("True")
# else:
#     print("False")


'''19. Write a python program to check if a set is a subset of another set using issubset(). Return True if yes, False if not.
    Data:
        x = {4, 5}
        y = {1, 2, 3, 4, 5}
    Expected Output:
        True
        False'''

# x = {4, 5}
# y = {1, 2, 3, 4, 5}
# is_subset = x.issubset(y)
# print(is_subset)


'''20. Write a Python program to check if two given sets are disjoint.
    Data:
        a = {1,2,3}
        b = {4,5,6}
        c = {3}
    Expected Output:
        True
        False'''

# a = {1,2,3}
# b = {3}
# is_disjoint = a.isdisjoint(b)
# print(is_disjoint)