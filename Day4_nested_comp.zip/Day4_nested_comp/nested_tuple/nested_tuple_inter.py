# 1.
# data = [('tuple1', '12.20'), ('tuple2', '15.10'), ('tuple3', '24.5')]
# sorted_data = sorted(data, key=lambda x: float(x[1]), reverse=True)
# print(sorted_data)

# 2.
# data = [(), (), ('',), ('a', 'b'), ('a', 'b', 'c'), ('d')]
# filtered = [t for t in data if t != ()]
# print(filtered)

# 3.
# data = [10, 20, 30, (10, 20), 40]
# count = 0
# for item in data:
#     if isinstance(item, tuple):
#         break
#     count += 1
# print(count)

# 4.
# data = (('333', '33'), ('1416', '55'))
# converted = tuple(tuple(int(i) for i in inner) for inner in data)
# print(converted)

5.
# test1 = ((1, 2),)
# test2 = ((3, 4),)
# result = test1 + test2
# print("The original tuple 1 :", test1)
# print("The original tuple 2 :", test2)
# print("Tuples after Concatenating :", result)

# 6.
# lst = [(1, 2), (5, 7), (3, 6), (1, 2)]
# unique = list(dict.fromkeys(lst))
# print(unique)

# 7.
# x = [(None, 2), (None, None), (3, 4), (12, 3), (None, )]
# result = [t for t in x if any(v is not None for v in t)]
# print("The original list is :", x)
# print("Removed None Tuples :", result)

# 8.
# data = [(14, 3), (23, 41), (33, 62), (1, 3), (3, 3)]
# element = 3
# result = [t for t in data if element in t]
# print(result)

# 9.
# data = ["('Boss', 3)", "('Suresh', 6)", "('Dinesh', 9)"]
# converted = list(map(eval, data))
# print("The original list is :", data)
# print("The list tuple after conversion :", converted)

10.
data = [(4, 5, 9), (-3, 2, 3), (-3, 5, 6), (4, 6)]
result = [t for t in data if all(i > 0 for i in t)]
print("The original list is :", data)
print("Positive elements Tuples :", result)
