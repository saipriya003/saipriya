import random

# 1. Write a Python program to check whether the list is empty or not.

# my_list = []
# if not my_list:
#     print("The list is empty")
# else:
#     print("List is not empty")

''' 2. Write a Python program to access the index of all the elements in a list.
        Data:
            x = [5, 15, 35, 8, 98]
        Expected Output:
            0 5
            1 15
            2 35
            3 8
            4 98 '''

# x = [5, 15, 35, 8, 98]
# for index,elements in enumerate(x):
#     print(f"{index} {elements}")


''' 3. Write a Python program to convert a list of characters into a string.
        Data:
            x = ['a', 'b', 'c', 'd']
        Expected Output:
            abcd '''

# x = ['a', 'b', 'c', 'd']
# result = ''.join(x)
# print(result)


''' 4. Write a Python program to find the index of specified item in a list.
        Data:
            x = [10, 30, 4, -6]
        Expected Output:
            Index of 4 is 2 '''

# x = [10, 30, 4, -6]
# item = int(input("Enter the element to be find: "))
# if item in x:
#     index = x.index(item)
#     print(f"Index of {item} is {index}")
# else:
#     print(f"{item} not found in the list")

''' 5. Write a Python program to print the sum of all the items in a list.
    Data:
        lt = [1, 2, -8]
    Expected Output:
        sum is -5 '''

# my_list = [1,2,-8]
# total = sum(my_list)
# print(total)


''' 6. Write a Python program to multiply all the items in a list.
        Data:
            [1, 2, -8]
        Expected Output:
            -16 '''

# my_list = [1,2,-8]
# product = 1
# for num in my_list:
#     product *= num
# print(product)

''' 7. Write a Python program to get the largest number from a list.
        Data:
            [1, 2, -8, 0]
        Expected Output:
            2 '''
# Data = [1,2,-8,0]
# largest_num = max(Data)
# print(largest_num)

''' 8. Write a Python program to get the smallest number from a list. 
        Data:
            [1, 2, -8, 0]
        Expected Output:
            -8 '''

# Data = [1,2,-8,0]
# smallest_num = min(Data)
# print(smallest_num)

''' 9. Write a Python program to remove duplicate items from a list.
        Data:
            a = [10,20,30,20,10,50,60,40,80,50,40]
        Expected Output:
            [10, 20, 30, 50, 60, 40, 80] '''

# a = [10, 20, 30, 20, 10, 50, 60, 40, 80, 50, 40]
# unique_list = []
# for item in a:
#     if item not in unique_list:
#         unique_list.append(item)
# print(unique_list)


''' 10. Write a Python program to clone or copy a list.
        Data:
            x = [10, 22, 44, 23, 4]
        Expected Output:
            X - [10, 22, 44, 23, 4]
            Y - [10, 22, 44, 23, 4] '''

# x = [10, 22, 44, 23, 4]
# # X = x.copy()
# # Y = x.copy()
# # print(X)
# # print(Y)


''' 11. Write a Python program to convert a tuple into a List.
        Data:
            x = 
        Expected Output:
            (1, 2, 3, 4, 5)
            [1, 2, 3, 4, 5] '''

# my_tuple = (1,2,3,4,5)
# my_list = list(my_tuple)
# print(my_list)

''' 12. Write a Python program to print the numbers of a specified list after removing even numbers from it.
        Data:
            x = [7, 8, 120, 25, 44, 20, 27]
        Expected Output:
            [7, 25, 27] '''

# my_list = [7, 8, 120, 25, 44, 20, 27]
# odd = []
# for i in my_list:
#     if i % 2 != 0:
#         odd.append(i)
# print(odd)

''' 13. Write a Python program to shuffle and print a specified list. 
        Data:
            x = ['Red', 'Green', 'White', 'Black', 'Pink', 'Yellow']
        Expected Output:
            ['Pink', 'Black', 'Red', 'Yellow', 'White', 'Green'] '''

# x = ['Red', 'Green', 'White', 'Black', 'Pink', 'Yellow']
# random.shuffle(x)
# print(x)


''' 14. Write a Python program to append the second list to the first list.
        Data:
            x = [1, 2, 3, 0]
            y = ['Red', 'Green', 'Black']
        Expected Output:
            [1, 2, 3, 0, 'Red', 'Green', 'Black'] '''

# x = [1, 2, 3, 0]
# y = ['Red', 'Green', 'Black']
# my_list = x + y
# print(my_list)

''' 15. Write a Python program to select an item randomly from a list.
        Data:
            x = ['Red', 'Blue', 'Green', 'White', 'Black']
        Expected Output:
            White '''

# x = ['Red', 'Blue', 'Green', 'White', 'Black']
# random_item = random.choice(x)
# print(random_item)


''' 16. Write a Python program to get unique values from a list.
        Data:
            Original List :  [10, 20, 30, 40, 20, 50, 60, 40]
        Expected Output:
            List of unique numbers :  [40, 10, 50, 20, 60, 30] '''

# Original_List = [10, 20, 30, 40, 20, 50, 60, 40]
# unique_list = []
# for item in Original_List:
#     if item not in unique_list:
#         unique_list.append(item)
# print(unique_list)


''' 17. Write a Python program to get variable unique identification number or string.
        Data:
            var1 = 'Python'
            var2 = 123
        Expected Output:
            186756869b0
            7ffea3a83660 '''


''' 18. Write a Python program to print common elements from two lists using set().
        Data:
            x = ("Red", "Green", "Orange", "White")
            y = ("Black", "Green", "White", "Pink")
        Expected Output:
            {'White', 'Green'} '''

x = ("Red", "Green", "Orange", "White")
y = ("Black", "Green", "White", "Pink")

# common = set(x) & set(y)
# print(common)

''' 19. Write a Python program to convert a list of multiple integers into a single integer.
        Data:
            x = [11, 22, 33]
        Expected Output:
            112233 '''

# x = [11, 22, 33]
# string = int(''.join(map(str,x)))
# print(string)


''' 20. Write a Python program to create multiple lists.
        Data:
            x = {}
        Expected Output:
            {'1': [], '2': [], '3': [], '4': [], '5': [], '6': [], '7': [], '8': [], '9': []} '''

x = {}
for i in range(1, 10):
    x[str(i)] = []
print(x)
