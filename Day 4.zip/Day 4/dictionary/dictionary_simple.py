#1Q:
# x = {0: 10, 1: 20}
# y = {2: 30}
# x.update(y)
# print(x)


#2Q:
# d = {"a":10, "b":20, "c":30}
# for key, value in d.items():
#     print(f"{key} -> {value}")


# #3Q:
# d = {"data1":100, "data2":-50, "data3":200}
# print(sum(d.values()))


#4Q:
# d = {"data1":100, "data2":-50, "data3":200}
# result = 1
# for v in d.values():
#     result *= v
# print(result)


#5Q:
# d = {"a":1, "b":2, "c":3, "d":4}
# print(d)
# d.pop("a")
# print(d)


#6Q:
# keys = ["Chandler", "Monica", "Joey"]
# values = ["Sarcasm", "Chef", "Food"]
# print(dict(zip(keys, values)))


#7Q:
# data = {'Chandler': 'Sarcasm', 'Monica': 'Chef', 'Joey': 'Food', 'Ross': 'Dinosaur', 'Rachel': 'Fashion'}
# for key in sorted(data):
#     print(f"{key}: {data[key]}")


#8Q:
# d = {}
# if not d:
#     print("Dictionary is empty")
# else:
#     print("Dictionary is not empty")


#9Q:
# d = {'physics': 90, 'math': 100, 'chemistry': 96}
# for key in d.keys():
#     print(key)


#10Q:
# d1 = {1:10, 2:20}
# d2 = {3:30, 4:40}
# d3 = {5:50, 6:60}
# d = {}
# for dic in (d1, d2, d3):
#     d.update(dic)
# print(d)


#11Q:
# n = 6
# print({x: x*x for x in range(1, n+1)})


#12Q:
# print({x: x**2 for x in range(1, 16)})


#13Q:
# d1 = {"a":10, "b":20}
# d2 = {"x":30, "y":40}
# merged = {**d1, **d2}
# print(merged)


#14Q:
# d = {"Bihar":'Patna', "Sikkim":'Gangtok', "Goa":'Panaji'}
# for k, v in d.items():
#     print(f"{k}\t{v}")


#15Q:
# from collections import Counter
#
# d1 = {'a': 10, 'b': 20, 'c':30}
# d2 = {'a': 30, 'b': 20, 'd':40}
# result = Counter(d1) + Counter(d2)
# print(result)


#16Q:
# from itertools import product
#
# data = {'1':['a','b'], '2':['c','d']}
# for combo in product(*data.values()):
#     print(''.join(combo))


#17Q:
# d = {'a':500, 'b':5874, 'c': 560, 'd':400, 'e':5874, 'f': 20}
# top_keys = sorted(d, key=d.get, reverse=True)[:3]
# print(top_keys)


#18Q:
# d = {'C1':[1,2,3], 'C2':[5,6,7], 'C3':[9,10,11]}
# columns = d.keys()
# rows = zip(*d.values())
#
# print(" ".join(columns))
# for row in rows:
#     print(" ".join(str(i) for i in row))

#19Q:
# d = [1, 2, 3, 4]
# nested = current = {}
# for item in d:
#     current[item] = {}
#     current = current[item]
# print(nested)


#20Q:
d = {'n1': [2, 3, 1], 'n2': [5, 1, 2], 'n3': [3, 2, 4]}
sorted_dict = {k: sorted(v) for k, v in d.items()}
print(sorted_dict)
