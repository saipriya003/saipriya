#1.
# matrix = [[i for i in range(5)] for _ in range(5)]
# print(matrix)


#2.
# x = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
# flattened = [item for sublist in x for item in sublist]
# print(flattened)


#3.
# name = [["boss", "suresh", "karthi"], ["dinesh", "sai", "kumar"], ["murugan", "siva", "balu"]]
# result = [item for sublist in name for item in sublist if len(item) < 6]
# print(result)


# 4.
# name = [['suresh'], ['boss'], ['kumar']]
# for sublist in name:
#     print(sublist)


# 5.
# from itertools import cycle
#
# data = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n']
# n = 3
# result = [[] for _ in range(n)]
# for idx, val in zip(cycle(range(n)), data):
#     result[idx].append(val)
# print(result)


# 6.
# lists = [[1,2,3], [4,5,6], [7,8,9], [10,11,12]]
# max_list = max(lists, key=sum)
# print(max_list)


#7.
# from collections import OrderedDict
# data = [[10, 20], [40], [30, 56, 25], [10, 20], [33], [40]]
# seen = []
# for lst in data:
#     if lst not in seen:
#         seen.append(lst)
# print(seen)


# 8.
# zeros = [[0, 0] for _ in range(3)]
# print(zeros)


# 9.
# grid = [[1, 2, 3] for _ in range(3)]
# print(grid)

10.
a = [[1, 3], [5, 7], [9, 11]]
b = [[2, 4], [6, 8], [10, 12, 14]]

zipped = [x + y for x, y in zip(a, b)]
print(zipped)
