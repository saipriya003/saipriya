#1.
# X = ['a', ['b', ['c', 'd'], 'e', 'f'], 'g', 'h']
# print(X)

#2.
# L = ['a', 'b', ['c', 'd', ['e', 'f']], 'g', 'h']
# print(L[2])
# print(L[2][2])
# print(L[2][2][0])

#3.
# L = ['1', '2', ['3', '4', ['5', '6']], '7', '8']
# print(L[-3])
# print(L[-3][-1])
# print(L[-3][-1][0])


#4.
# X = ['12', ['45', '23'], '89']
# X[1][1] = 0
# print(X)


#5.
# X = ['a', ['b', 'c'], 'd']
# X[1].append('xx')
# print(X)

#6.
# X = ['123', ['567', '346'], '678']
# X[1].insert(0, '555')
# print(X)

#7.
# X = ['boss', ['suresh', 'kumar'], 'siva']
# X[1].extend(['dinesh'])
# print(X)



#8.
# L = ['a', ['b', 'c', 'd'], 'e']
# removed_item = L[1].pop(1)
# print(L)
# print(removed_item)

#
# 9.
# L = ['a', ['b', 'c', 'd'], 'e']
# L[1].remove('c')
# print(L)



#10.
# X = ['34', ['56', '24'], '45']
# print(len(X))
# print(len(X[1]))


#11.
X = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
for sublist in X:
    for item in sublist:
        print(item, end=' ')
