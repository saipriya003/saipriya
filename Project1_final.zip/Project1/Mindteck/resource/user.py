from flask_restful import Resource, reqparse
from db import get_connection

# Initialize the parser
parser = reqparse.RequestParser()
parser.add_argument('name', type=str, required=True, help='Name is required')
parser.add_argument('email', type=str, required=True, help='Email is required')
parser.add_argument('phone', type=str, required=True, help='Phone is required')
parser.add_argument('message', type=str, required=False)

class User(Resource):
    def get(self):
        try:
            conn = get_connection()
            with conn.cursor() as cursor:
                cursor.execute("SELECT id, name, email, phone, message, created_at FROM contacts ORDER BY created_at DESC")
                users = cursor.fetchall()
            return {"users": users}, 200
        except Exception as e:
            return {"error": str(e)}, 500
        finally:
            conn.close()

    def post(self):
        args = parser.parse_args()
        name = args['name']
        email = args['email']
        phone = args['phone']
        message = args.get('message', '')

        try:
            conn = get_connection()
            with conn.cursor() as cursor:
                sql = "INSERT INTO contacts (name, email, phone, message) VALUES (%s, %s, %s, %s)"
                cursor.execute(sql, (name, email, phone, message))
                conn.commit()
            return {"message": "User added successfully."}, 201
        except Exception as e:
            return {"error": str(e)}, 500
        finally:
            conn.close()
