#1
# def gcd(a, b):
#     while b != 0:
#         a, b = b, a % b
#     return a
#
# def lcm(a, b):
#     return abs(a * b) // gcd(a, b)
#
# # Test cases
# print(lcm(4, 6))   # Output: 12
# print(lcm(15, 17)) # Output: 255



#2
# def sum_of_cubes(n):
#     total = 0
#     i = 1
#     while i < n:
#         total += i ** 3
#         i += 1
#     return total
#
# # Example usage:
# print("Sum of cubes: ", sum_of_cubes(3))  # Output: 9



#3
# nums = [10, 20, 30, 40, 50, 60, 70, 80, 90]
#
# index = 2  # since list is 0-based, 3rd element is at index 2
#
# while nums:
#     # Remove and print the element at current index
#     print(nums.pop(index))
#     if not nums:
#         break
#     # Move index 2 steps ahead (because after removing one element, list shrinks)
#     index = (index + 2) % len(nums)

#4.
# def find_triplets(nums):
#     nums.sort()
#     triplets = []
#     n = len(nums)
#
#     for i in range(n - 2):
#         if i > 0 and nums[i] == nums[i - 1]:
#             continue
#
#         left, right = i + 1, n - 1
#         while left < right:
#             total = nums[i] + nums[left] + nums[right]
#
#             if total == 0:
#                 triplets.append((nums[i], nums[left], nums[right]))
#                 while left < right and nums[left] == nums[left + 1]:
#                     left += 1
#                 while left < right and nums[right] == nums[right - 1]:
#                     right -= 1
#                 left += 1
#                 right -= 1
#
#             elif total < 0:
#                 left += 1
#             else:
#                 right -= 1
#     return triplets
# x = [1, -6, 4, 2, -1, 2, 0, -2, 0]
# result = find_triplets(x)
# print(result)

#5
# def find_n(s):
#     power = 1
#     concatenated = ""
#     while len(concatenated) < len(s):
#         concatenated += str(2 ** power)
#         power += 1
#     if concatenated == s:
#         return power - 1
#     else:
#         return -1  # if no exact match
#
# # Test cases
# print(find_n("2481632"))    # Output: 5
# print(find_n("248163264"))  # Output: 6



#6
# def sum_of_digits(n):
#     total = 0
#     while n > 0:
#         total += n % 10
#         n //= 10
#     return total
#
# def process_number(num):
#     while num > 0:
#         prev = num
#         num = num - sum_of_digits(num)
#     return prev
#
# # Test cases
# print(process_number(9))
# print(process_number(21))



#7
# def sum_abs_diff(arr):
#     total = 0
#     i = 0
#     n = len(arr)
#     while i < n:
#         j = i + 1
#         while j < n:
#             total += abs(arr[j] - arr[i])
#             j += 1
#         i += 1
#     return total
#
# # Test cases
# print(sum_abs_diff([1, 2, 3]))  # Output: 4
# print(sum_abs_diff([1, 4, 5]))  # Output: 8



#8
# def common_divisors_count(a, b):
#     count = 0
#     i = 1
#     limit = min(a, b)
#     while i <= limit:
#         if a % i == 0 and b % i == 0:
#             count += 1
#         i += 1
#     return count
#
# # Test data
# pairs = [(2, 4), (2, 8), (12, 24)]
#
# for a, b in pairs:
#     print("Number of common divisors: ", common_divisors_count(a, b))


#9
# def is_palindrome(num):
#     return str(num) == str(num)[::-1]
#
# def reverse_number(num):
#     return int(str(num)[::-1])
#
# def reverse_add_until_palindrome(num):
#     while not is_palindrome(num):
#         rev = reverse_number(num)
#         num = num + rev
#     return num
#
# # Test cases
# print(reverse_add_until_palindrome(1234))  # Output: 5555
# print(reverse_add_until_palindrome(1473))  # Output: 9339
# print(reverse_add_until_palindrome(121))   # Output: 121


#10.
# def max_subsequence_sum(arr):
#     max_sum = current_sum = arr[0]
#     for num in arr[1:]:
#         current_sum = max(num, current_sum + num)
#         max_sum = max(max_sum, current_sum)
#     return max_sum
#
# while True:
#     n = int(input("Input number of sequence of numbers you want to input (0 to exit): "))
#     if n == 0:
#         break
#     print("Input numbers:")
#     sequence = [int(input()) for _ in range(n)]
#     result = max_subsequence_sum(sequence)
#     print("Maximum sum of the said contiguous subsequence:")
#     print(result)


#11.
# from itertools import combinations
#
# while True:
#     user_input = input("Input number of combinations and sum, input 0 0 to exit:\n")
#     n, s = map(int, user_input.split())
#     if n == 0 and s == 0:
#         break
#
#     digits = list(range(10))
#     valid_combinations = [combo for combo in combinations(digits, n) if sum(combo) == s]
#     print(len(valid_combinations))


#12.
# def is_prime(num):
#     if num < 2:
#         return False
#     if num == 2:
#         return True
#     if num % 2 == 0:
#         return False
#     for i in range(3, int(num**0.5) + 1, 2):
#         if num % i == 0:
#             return False
#     return True
#
# def sum_first_n_primes(n):
#     primes = []
#     num = 2
#     while len(primes) < n:
#         if is_prime(num):
#             primes.append(num)
#         num += 1
#     return sum(primes)
#
# while True:
#     n = int(input("Input a number (n≤10000) to compute the sum:(0 to exit)\n"))
#     if n == 0:
#         break
#     print(f"Sum of first {n} prime numbers:")
#     print(sum_first_n_primes(n))


#13.
# def decompress(text):
#     result = ""
#     i = 0
#     while i < len(text):
#         if text[i] == '#':
#             count = int(text[i+1])
#             char = text[i-1]
#             result = result[:-1] + char * count
#             i += 2
#         else:
#             result += text[i]
#             i += 1
#     return result
# inputs = ["XY#6Z1#4023", "#39+1=1#30"]
#
# for item in inputs:
#     print(f"Original text: {item}")
#     print(decompress(item))


#14.
# def count_combinations(n):
#     count = 0
#     for p in range(0, min(n, 1000) + 1):
#         for q in range(0, min(n - p, 1000) + 1):
#             for r in range(0, min(n - p - q, 1000) + 1):
#                 s = n - p - q - r
#                 if 0 <= s <= 1000:
#                     count += 1
#     return count
#
# try:
#     while True:
#         n = int(input("Input a positive integer: (ctrl+d to exit)\n"))
#         print("Number of combinations of a,b,c,d:", count_combinations(n))
# except EOFError:
#     pass


#15.
# while True:
#     n = int(input("Input number of rows/columns (0 to exit)\n"))
#     if n == 0:
#         break
#     matrix = []
#     print("Input cell value:")
#     for _ in range(n):
#         row = list(map(int, input().split()))
#         matrix.append(row)
#
#     col_sums = [sum(col) for col in zip(*matrix)]
#     print("Result:")
#     for row in matrix:
#         print("  ".join(f"{x}" for x in row))
#     print("  ".join(f"{x}" for x in col_sums))


#16.
# def gcd(a, b):
#     while b:
#         a, b = b, a % b
#     return a
#
# def phi(n):
#     count = 0
#     for i in range(1, n):
#         if gcd(n, i) == 1:
#             count += 1
#     return count
# for x in [10, 15, 33]:
#     print(phi(x))



#17.
# def is_coprime(a, b):
#     while b:
#         a, b = b, a % b
#     return a == 1
# pairs = [(17, 13), (15, 21), (25, 45)]
# for a, b in pairs:
#     print(is_coprime(a, b))