#1Q:
# data1 = [(5, 4), (5, 3), (2, 4)]
# data2 = [(1, 2, 4), (3, 4, -6), (3, 5), (1, 4, 2, 2)]
#
# print([sum(t) for t in data1])
# print([sum(t) for t in data2])


#2Q:
# x = (1,2,3,4)
# y = (3,5,2,1)
# z = (2,2,3,1)
# l = (1,2,3,4)
#
# result = tuple(map(sum, zip(x, y, z, l)))
# print(result)


#3Q:
# data = (('Coffee', 'Tea', 'Boost'), ('Badam', 'Pista', 'Walnut'), ('Sangeetha', 'A2B', 'Saravana'))
#
# print("Bournvita" in sum(data, ()))
# print("Saravana" in sum(data, ()))


#4Q:
# t = (9, 20, 40, 10, 70)
# result = int(''.join(str(i) for i in t))
# print(result)



#5Q:
# data = (('222', '33'), ('546', '678'))
# converted = tuple(tuple(int(i) for i in sub) for sub in data)
# print(converted)


#6Q:
# data1 = ((5, 30, 10, 12), (30, 20, 56, 54), (26, 80, 67, 32), (1, 4, 3, 9))
# data2 = ((1, 1, -7), (10, -15, 56), (71, -60, -39), (-10, 2, 9))
#
# def average_columns(data):
#     return [sum(col)/len(col) for col in zip(*data)]
#
# print(average_columns(data1))
# print(average_columns(data2))


#7Q:
# from functools import reduce
# import operator
#
# def multiply_tuple(t):
#     return reduce(operator.mul, t)
#
# print(multiply_tuple((4, 3, 5, 2, -2, 10)))
# print(multiply_tuple((2, 6, 8, 7, 3, 1, 9)))



#8Q:
# s = "aidinasaur.com"
# t = tuple(s)
# print(t)
# print(type(t))


#9Q:
# n = input("Enter a number n: ")
# n1 = int(n)
# n2 = int(n*2)
# n3 = int(n*3)
# print(f"The value is: {n1 + n2 + n3}")


#10Q:
# x = (2, 4, 3, 5, 4, 6, 7, 8, 6, 1)
# y = tuple("HELLO NATURE")
#
# print(x[3:5])
# print(x[:6])
# print(x[5:])
# print(x[:])
# print(x[2:6])
# print(y)
# print(y[2:6])
# print(y[::4])
# print(y[-3:-1])


#11Q:
# import calendar
#
# year = int(input("Enter the year: "))
# month = int(input("Enter the month: "))
#
# print(calendar.month(year, month))


#12Q:
# def triple_sum(t):
#     return sum(t) * 3 if t[0] == t[1] == t[2] else sum(t)
#
# print(triple_sum((1, 2, 3)))
# print(triple_sum((3, 3, 3)))


#13Q:
# def count_4(lst):
#     return lst.count(4)
# print(count_4([1, 5, 6, 8, 4]))
# print(count_4([1, 4, 6, 2, 7, 5]))


#14Q:
# def vowel(c):
#     return c.lower() in 'aeiou'
#
# print(vowel('c'))
# print(vowel('e'))


#15Q:
# import math
# a = (12, 17)
# print(math.gcd(*a))


#16Q:
# import math
# def lcm(a, b):
#     return abs(a*b) // math.gcd(a, b)
#
# a = (4, 6)
# print(lcm(*a))


#17Q:
# import math
# a = float(input("Enter side a: "))
# b = float(input("Enter side b: "))
# print("Hypotenuse:", math.hypot(a, b))


#18Q:
# x = ('tuple', True, 5.2, 9)
#
# if isinstance(x, tuple):
#     print("x is a tuple")
# elif isinstance(x, list):
#     print("x is a list")
# elif isinstance(x, set):
#     print("x is a set")


#19Q:
# x = ("apple", "banana", "cherry")
# print(x)
# x = x[:1] + ("kiwi",) + x[2:]
# print(x)


#20Q:
x = (("boss", 10), ("suresh", 12), ("anand", 14), ("siva", 20), ("bala", 25), ("karthi", 30))
d = {v: k for k, v in x}
print(d)
