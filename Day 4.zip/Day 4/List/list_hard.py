#1question

# def rotate_list(lst, n, direction='left'):
#     length = len(lst)
#     n = n % length  # handle rotations greater than list length
#     if direction == 'left':
#         return lst[n:] + lst[:n]
#     elif direction == 'right':
#         return lst[-n:] + lst[:-n]
#     else:
#         raise ValueError("Direction must be 'left' or 'right'")
#
# data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
#
# print("Rotate the said list in left direction by 4:")
# print(rotate_list(data, 4, 'left'))
#
# print("Rotate the said list in left direction by 2:")
# print(rotate_list(data, 2, 'left'))
#
# print("Rotate the said list in Right direction by 4:")
# print(rotate_list(data, 4, 'right'))
#
# print("Rotate the said list in Right direction by 2:")
# print(rotate_list(data, 2, 'right'))


#2Q:
# from collections import Counter
#
# data = [2,3,8,4,7,9,9,2,6,5,1,6,1,3,3,4,6,9,1,2]
# counts = Counter(data)
# max_occurrence = max(counts.values())
# max_items = [item for item, count in counts.items() if count == max_occurrence]
# print(max_items[0])


#3Q:
# data = [2,3,8,4,7,9,7,2,6,5,1,5,1,2,3,4,6,9,3,2]
# indices = [0, 3, 5, 7, 10]
#
# print("Index list:")
# print(indices)
# items = [data[i] for i in indices]
# print("\nItems with specified index of the said list:")
# print(items)


#4Q:
# def is_sorted(lst):
#     return all(lst[i] <= lst[i+1] for i in range(len(lst)-1))
#
# list1 = [1, 2, 4, 6, 8, 10, 12, 14, 16, 17]
# list2 = [2, 3, 8, 4, 7, 9, 8, 2, 6, 5, 1, 6, 1, 2, 3, 4, 6, 9, 1, 2]
# print("Is the said list is sorted!")
# print(is_sorted(list1))
# print("Is the said list is sorted!")
# print(is_sorted(list2))



#5Q:
# l = [{'Black': 'Cotton'}, {'Red': 'Pulses'}, {'Laterite': 'Cashews'}, {'Black': 'Cotton'}, {'Alluvial': 'Rice'}]
#
# unique = []
# seen = set()
# for d in l:
#     t = tuple(d.items())
#     if t not in seen:
#         seen.add(t)
#         unique.append(d)
# print("After removing duplicate dictionary of the said list:")
# print(unique)


#6Q:
# data = [('boss', 98, 99), ('kumar', 97, 96), ('karthi', 91, 94), ('siva', 94, 98)]
#
# def extract_nth(lst, n):
#     return [t[n] for t in lst]
# print("Extract nth element ( n = 0 ) from the said list of tuples:")
# print(extract_nth(data, 0))
# print("\nExtract nth element ( n = 2 ) from the said list of tuples:")
# print(extract_nth(data, 2))


#7Q:
# def are_elements_unique(lst):
#     return len(lst) == len(set(lst))
#
# list1 = [3, 7, 4, 6, 8, 2, 1, 4, 10, 11, 14, 12, 16, 17]
# list2 = [2, 4, 6, 8, 10, 12, 14]
#
# print("Is the said list contains all unique elements!")
# print(are_elements_unique(list1))
# print("Is the said list contains all unique elements!")
# print(are_elements_unique(list2))


#8Q:
# data = [('siva', 98, 99), ('bala', 97, 96), ('kumar', 91, 94), ('boss', 94, 98)]
#
# def sort_by_index(lst, index):
#     return sorted(lst, key=lambda x: x[index])
#
# print("Sort the said list of lists by a given index ( Index =  0 ) of the inner list")
# print(sort_by_index(data, 0))
# print("\nSort the said list of lists by a given index ( Index =  2 ) of the inner list")
# print(sort_by_index(data, 2))


#9Q:
# x = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# y = [5, 4, 7, 9]

# result = [item for item in x if item not in y]
# print("Remove all elements from 'x' present in 'y:")
# print(result)


#10Q:
# x1 = [3, 6, 2, 7, 9, 23, 6, 12, 24]
# diff = [x1[i+1] - x1[i] for i in range(len(x1) - 1)]
# print("Difference between elements (n+1th – nth) of the said list :")
# print(diff)


#11
# data = ['Kannada', 'Telugu', 'Hindi', 'Tamizh', 'Odia']
#
# def is_substring_present(lst, substring):
#     return any(substring in item for item in lst)
#
# substring1 = "ugu"
# substring2 = "alaya"
#
# print("Substring to search:", substring1)
# print("Check if a substring presents in the said list of string values:", is_substring_present(data, substring1))
# print("\nSubstring to search:", substring2)
# print("Check if a substring presents in the said list of string values:", is_substring_present(data, substring2))


#12
# data = ['Soverign', 'Socialist', 'Secular', 'Democratic', 'Republic']
# result = data[::2]
# print(result)


#13
# main_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
# nested_lists = [[11, 18, 23, 25, 42], [7, 11, 18, 24, 28], [1, 5, 8, 18, 15, 16]]
#
# result = [[item for item in sublist if item in main_list] for sublist in nested_lists]
#
# print("Intersection of said nested lists:")
# print(result)



#14
# nested_lists = [[11, 18, 23, 25, 42], [7, 11, 18, 24, 28], [1, 5, 8, 18, 15, 16]]
#
# common_elements = set(nested_lists[0])
# for lst in nested_lists[1:]:
#     common_elements &= set(lst)
# print("Common element(s) in nested lists:")
# print(list(common_elements))


#15
# data = ['suresk', 'kumar', 'siva', 'boss', 'bala']
#
# result = [s[::-1] for s in data]
# print("Reverse strings of the said given list:")
# print(result)


#16
# data = [(2, 7), (2, 6), (1, 8), (4, 9)]
#
# products = [a * b for a, b in data]
#
# result = (max(products), min(products))
# print("Maximum and minimum product from the pairs of the said tuple of list:")
# print(result)


#18
# x = [1, 2, 3, 4, 5, 6, 7]
# y = [10, 20, 30, 40, 50, 60, 70]
# z = [100, 200, 300, 400, 500, 600, 700]
#
# result = [val for triplet in zip(x, y, z) for val in triplet]
#
# print("Interleave multiple lists:")
# print(result)


#19
# words = ['suresk', 'kumar#', 'siva', 'boss@', 'bala']
# chars = ['#', 'color', '@']
# new_list = [word if not any(c in word for c in chars) else '' for word in words]
# print("Character list:")
# print(chars)
# print("\nNew list:")
# print(new_list)



#20
data = [4, 1, 9, 6, 8, 3, 1, 9, 10, 11, 8, 12]
start, end = 8, 10

result = sum(data[start:end+1])
print("Range:", start, ",", end)
print("Sum of the specified range:")
print(result)
