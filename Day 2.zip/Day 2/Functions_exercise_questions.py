# Write a function to hours to minutes , user should able to give hours as input

# def hourstominutes(hours):
#     min = hours * 60
#     print(f"{hours} hours is equal to {min} minutes")
#
# hr = int(input("Enter the hours: "))
# hourstominutes(hr)


# Write a function to convert centimeter to meter , user should be able to give centimeter as input
# your Answer

# def centimeter_to_meter(cm):
#     meters = cm / 100
#     print(f"{cm} centimeter is equal to {meters} meters")
#
# centimeter = float(input("Enter the centimetr: "))
# centimeter_to_meter(centimeter)

# Write a function to convert miles to Kilometer , user shoulb be able to give miles as input

# your Answer
# def miles_to_km(mile):
#     kilometers = mile * 1.60
#     print(f"The equivalent kilometer for miles is {kilometers} km")
#
# miles = int(input("Enter the miles: "))
# miles_to_km(miles)

# Write a function to convert pounds to Kilogram , user shoulb be able to give pounds as input
# your Answer

# def pounds_to_kg(pound):
#     kilograms = pounds * 0.453592
#     print(f"Weight of kilograms is {kilograms} kg")
#
# pounds = float(input("Enter the weight of pounds: "))
# pounds_to_kg(pounds)

# Write a function to calculate simple interest # all input shoulb be given by the user
# your Answer

# def simple(principal_amount,rate_of_interest,time):
#     Simple_interest = (principal_amount * rate_of_interest * time) / 100
#     print(f"The SI is Rs.{Simple_interest}")
#
#
# principal_amount = int(input("Enter P in Rs: "))
# rate_of_interest = int(input("Enter R in %:"))
# time = int(input("Enter time in years:"))
# simple(principal_amount,rate_of_interest,time)

# Write a function to calculate area of circle
# your Answer

# def area_of_circle(R):
#     area = 3.14 * R ** 2
#     print(f"Area of a circle is {area} cm")
#
#
# radius = float(input("Enter the radius: "))
# area_of_circle(radius)

# Write a function to calculate circumference of circle

# def circum_of_circle(radius):
#     circumference = 2 * 3.14 * radius
#     print(f"Circumference of the circle is {circumference}")
#
# radius = float(input("Enter the radius: "))
# circum_of_circle(radius)

# Write a function to calculate perimeter of square

# def perimeter_of_square(sides):
#     perimeter = 4 * sides
#     print(f"The perimeter of a square is {perimeter}")
#
# side = float(input("Enter the length of one side of the square : "))
# perimeter_of_square(side)

# Write a fucntion to calculate area of square

# def area_of_square(side):
#     area = side * side
#     print(f"Area of the square is {area}")
#
# side = float(input("Enter the length of one side of the square: "))
# area_of_square(side)

# Write a function to area of traingle

def area_of_triangle(base,height):
    area = 0.5 * base * height
    print(f"Area of triangle is {area}")

base = float(input("Enter the base of the triangle : "))
height = float(input("Enter the height of the triangle : "))
area_of_triangle(base,height)










