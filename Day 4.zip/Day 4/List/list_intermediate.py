''' 1. Write a Python program to count the number of strings where the string length is 2 or more and
            the first and last characters of a string are same from the given data.
        Data:
            ['abc', 'xyz', 'aba', '1221']
        Expected Output:
            2 '''

# my_list =  ['abc', 'xyz', 'aba', '1221']
# count = 0
# for word in my_list:
#     if len(word) >= 2 and word[0] == word[-1]:
#         count += 1
# print(count)

''' 2. Write a Python function to find the list of words which are longer than the specified length from the given data.
        Data:
            (3, "The quick brown fox jumps over the lazy dog")
        Expected Output:
            ['quick', 'brown', 'jumps', 'over', 'lazy'] '''

# def long_words(n, text):
#     return [word for word in text.split() if len(word) > n]
#
# result = long_words(3, "The quick brown fox jumps over the lazy dog")
# print(result)


''' 3. Write a Python function that takes two parameters as lists and returns True if they have at least one common element.
        Data:
            (a, b) = ([1,2,2,4,5], [5,6,6,8,9])
            (a, b) = ([1,2,3,5,5], [6,7,9,9])
        Expected Output:
            True 
            None '''
# def common_element(list1, list2):
#     for elem in list1:
#         if elem in list2:
#             return True
#
# a, b = [1,2,2,4,5], [5,6,6,8,9]
# print(common_element(a, b))  # True
# a, b = [1,2,3,5,5], [6,7,9,9]
# print(common_element(a, b))  # None (no common element, so function returns None)



# 4. Write a Python program to generate a 3*4*6 3D array whose each element is '*'.

# array_3d = []
# for i in range(3):
#     layer = []
#     for j in range(4):
#         row = []
#         for k in range(6):
#             row.append('*')
#         layer.append(row)
#     array_3d.append(layer)
#
# print(array_3d)

''' 5. Write a Python program to generate and print a list of first and last 5 elements where the values are square of numbers 
       between 1 and 30 (both included).
    Data:
        range(1, 31) 
    Expected Output:
        Squares of first 5 numbers between 1 to 30: [1, 4, 9, 16, 25]
        Squares of last 5 numbers between 1 to 30: [676, 729, 784, 841, 900] '''

# squares = [x**2 for x in range(1, 31)]
# print("Squares of first 5 numbers between 1 to 30:", squares[:5])
# print("Squares of last 5 numbers between 1 to 30:", squares[-5:])

''' 6. Write a Python program to find the second smallest number in a list.
        Data:
            lt = [1, 2, -8, -2, 0, -2]
        Expected output:
            -2 '''
# lt = [1, 2, -8, -2, 0, -2]
# unique_sorted = sorted(set(lt))
# if len(unique_sorted) >= 2:
#     print(unique_sorted[1])
# else:
#     print("No second smallest number found")



''' 7. Write a Python program to find the second largest number in a list.
        Data:
            lt = [1, 2, 3, 5, 4]
        Expected output:
            4 '''
# lt = [1, 2, 3, 5, 4]
# unique_sorted = sorted(set(lt), reverse=True)
# if len(unique_sorted) >= 2:
#     print(unique_sorted[1])
# else:
#     print("No second largest number found")

''' 8. Write a Python program to get the frequency of the elements in a list and 
            print the occurances as a list of dictionary as shown in the expected output.
        Data:
            Original List :  [10, 10, 10, 10, 20, 20, 20, 30, 40, 40, 50, 50, 30]
        Expected Output:
            Frequency of the elements in the List :  Counter({10: 4, 20: 3, 30: 2, 40: 2, 50: 2})'''

# from collections import Counter
#
# lst = [10, 10, 10, 10, 20, 20, 20, 30, 40, 40, 50, 50, 30]
# freq = Counter(lst)
# print("Frequency of the elements in the List :", freq)

''' 9. Write a Python program to check whether a list contains a sublist or not. Return True if present, false if not.
        Data:
            a = [2,4,3,5,7]
            sublist1 = [4,3]
            sublist2 = [3,7]
        Expected Output:
            True
            False '''
# def contains_sublist(lst, sublst):
#     n, m = len(lst), len(sublst)
#     for i in range(n - m + 1):
#         if lst[i:i+m] == sublst:
#             return True
#     return False
# a = [2,4,3,5,7]
# sublist1 = [4,3]
# sublist2 = [3,7]
# print(contains_sublist(a, sublist1))  # True
# print(contains_sublist(a, sublist2))  # False


''' 10. Write a Python program to generate all sublists of a list.
        Data:
            l1 = [10, 20, 30, 40]
            l2 = ['X', 'Y', 'Z']
        Expected Output:
            [[], [1], [2], [1, 2], [3], [1, 3], [2, 3], [1, 2, 3]]
            [[], ['X'], ['Y'], ['X', 'Y'], ['Z'], ['X', 'Z'], ['Y', 'Z'], ['X', 'Y', 'Z']] '''

# from itertools import combinations
#
# def all_sublists(lst):
#     result = []
#     for r in range(len(lst)+1):
#         for combo in combinations(lst, r):
#             result.append(list(combo))
#     return result
#
# l1 = [1, 2, 3]
# l2 = ['X', 'Y', 'Z']
# print(all_sublists(l1))
# print(all_sublists(l2))

''' 11. Write a Python program to print all the prime numbers upto a specified number using Sieve of Eratosthenes method.
        Data:
            nums(10)
        Expected Output:
            2
            3
            5
            7
            None '''

# def sieve_of_eratosthenes(n):
#     primes = [True] * (n+1)
#     primes[0], primes[1] = False, False
#
#     for i in range(2, int(n**0.5) + 1):
#         if primes[i]:
#             for j in range(i*i, n+1, i):
#                 primes[j] = False
#
#     for i in range(2, n+1):
#         if primes[i]:
#             print(i)
#
# sieve_of_eratosthenes(10)

''' 12. Write a Python program to create a list by concatenating a given list which ranges from 1 to n.
        Data:
            list:['l', 'm']
            n = 4
        Expected Output:
            ['l1', 'm1', 'l2', 'm2', 'l3', 'm3', 'l4', 'm4'] '''
# lst = ['l', 'm']
# n = 4
# result = []
# for i in range(1, n+1):
#     for char in lst:
#         result.append(char + str(i))
# print(result)


''' 13. Write a Python program to change the position of every n-th value with the (n+1)th in a list.
        Data:
            list:[0, 1, 2, 3, 4, 5, 6, 7]
        Expected Output:
            [1, 0, 3, 2, 5, 4, 7, 6] '''
# lst = [0, 1, 2, 3, 4, 5, 6, 7]
# for i in range(0, len(lst)-1, 2):
#     lst[i], lst[i+1] = lst[i+1], lst[i]
# print(lst)

''' 14. Write a Python program to convert a pair of values into a sorted unique array.
        Data:
            List:  [(1, 2), (3, 4), (5, 6), (7, 8), (1, 2), (3, 4), (7, 8), (7, 8), (9, 10)]   
        Expected Output:
            Sorted Unique Data: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] '''
# data = [(1, 2), (3, 4), (5, 6), (7, 8), (1, 2), (3, 4), (7, 8), (7, 8), (9, 10)]
#
# unique_elements = set()
# for pair in data:
#     unique_elements.update(pair)
#
# sorted_unique = sorted(unique_elements)
# print("Sorted Unique Data:", sorted_unique)

''' 15. Write a Python program to sort a list of nested dictionaries.
        Data:
            Original List: 
                x = [{'Book': {'Novel': 'Hamlet'}}, {'Book': {'Novel': 'Sherlock Homes'}}, {'Book': {'Novel': 'Alchemist'}}]
        Expected Output:
            Sorted List: 
                [{'Book': {'Novel': 'Alchemist'}}, {'Book': {'Novel': 'Hamlet'}}, {'Book': {'Novel': 'Sherlock Homes'}}] '''

# x = [{'Book': {'Novel': 'Hamlet'}}, {'Book': {'Novel': 'Sherlock Homes'}}, {'Book': {'Novel': 'Alchemist'}}]
#
# sorted_list = sorted(x, key=lambda d: d['Book']['Novel'])
# print("Sorted List:", sorted_list)

''' 16. Write a Python program to remove duplicates from a list of lists.
        Data:
            Original List [[10, 30], [40], [30, 56, 23], [10, 20], [33], [40]]
        Expected Output:
            Unique List [[10, 20], [10, 30], [30, 56, 23], [33], [40]] '''

# original_list = [[10, 30], [40], [30, 56, 23], [10, 20], [33], [40]]
# unique = []
# seen = set()
# for sublist in original_list:
#     t = tuple(sorted(sublist))  # Sort to consider lists with same elements but different order as duplicates if needed
#     if t not in seen:
#         seen.add(t)
#         unique.append(sublist)
# print("Unique List", unique)

''' 17. Write a Python program to check whether all dictionaries in a list are empty or not.
        Data:
            x = [{},{},{}]
            y = [{1,2},{},{}]
        Expected Output:
            True
            False '''

# def all_dicts_empty(lst):
#     return all(len(d) == 0 for d in lst)
# x = [{},{},{}]
# y = [{1,2}, {}, {}]  # Note: {1, 2} is a set, not a dict; use {1: 'a', 2: 'b'} for dict
#
# print(all_dicts_empty(x))
# print(all_dicts_empty(y))

''' 18. Write a Python program to convert a nested list into a flat list.
        Data:
            lt = [0, 20, [30, 30], 40, 50, [60, 40, 80], [90, 100, 10, 119]]
        Expected Output:
            Flat list:[0, 20, 30, 30, 40, 50, 60, 40, 80, 90, 100, 10, 119] '''

# lt = [0, 20, [30, 30], 40, 50, [60, 40, 80], [90, 100, 10, 119]]
# flat_list = []
# for item in lt:
#     if isinstance(item, list):
#         flat_list.extend(item)
#     else:
#         flat_list.append(item)
# print("Flat list:", flat_list)

''' 19. Write a Python program to remove only the consecutive duplicates from given list.
        Data:
            lt = [0, 1, 1, 2, 3, 5, 4, 5, 6, 6, 7, 7, 8, 4, 4, 4]
        Expected Output:
            After removing consecutive duplicates:
                [0, 1, 2, 3, 5, 4, 5, 6, 7, 8, 4] '''

# lt = [0, 1, 1, 2, 3, 5, 4, 5, 6, 6, 7, 7, 8, 4, 4, 4]
#
# result = [lt[0]] if lt else []
# for i in range(1, len(lt)):
#     if lt[i] != lt[i-1]:
#         result.append(lt[i])
# print("After removing consecutive duplicates:")
# print(result)

''' 20. Write a Python program to pack consecutive duplicates of a given list into sublists.
        Data:
            Original list:
            [1, 0, 1, 2, 3, 4, 4, 5, 5, 6, 6, 7, 8, 9, 4, 4]
        Expected Output:
            After packing consecutive duplicates of the said list elements into sublists:
                [[1], [0], [1], [2], [3], [4, 4], [5, 5], [6, 6], [7], [8], [9], [4, 4]] '''
# lst = [1, 0, 1, 2, 3, 4, 4, 5, 5, 6, 6, 7, 8, 9, 4, 4]
#
# packed = []
# temp = [lst[0]]
# for i in range(1, len(lst)):
#     if lst[i] == lst[i-1]:
#         temp.append(lst[i])
#     else:
#         packed.append(temp)
#         temp = [lst[i]]
#
# packed.append(temp)  # Append the last group
# print("After packing consecutive duplicates of the said list elements into sublists:")
# print(packed)
