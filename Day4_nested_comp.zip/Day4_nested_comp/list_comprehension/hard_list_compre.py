# 1.
# original_list = [{'key1': 'value1', 'key2': 'value2'}, {'key1': 'value3', 'key2': 'value4'}]
# new_list = [{k: v for k, v in d.items() if k != 'key1'} for d in original_list]
# print(new_list)


# 2.
# lists = ['neutron', 'iron', 'proton', 'neuron', 'photon', 'photosynthesis', 'calcium', 'copper', 'carbon']
# def filter_by_start_letter(lst, letter):
#     return [item for item in lst if item.startswith(letter)]
# print("Original list:", lists)
# print("Items start with c:", filter_by_start_letter(lists, 'c'))
# print("Items start with p:", filter_by_start_letter(lists, 'p'))
# print("Items start with m:", filter_by_start_letter(lists, 'm'))



# 3.
# lst = [10, 0, 11, 2, 3, 4, 44, 5, 6, 6, 6, 7, 8, 9, 4, 4]
#
# packed = []
# for item in lst:
#     if not packed or item != packed[-1][0]:
#         packed.append([item])
#     else:
#         packed[-1].append(item)
#
# print("After packing consecutive duplicates:", packed)



# 4.
# def run_length_encoding(seq):
#     encoding = []
#     prev = None
#     count = 0
#     for c in seq:
#         if c == prev:
#             count += 1
#         else:
#             if prev is not None:
#                 encoding.append([count, prev])
#             prev = c
#             count = 1
#     encoding.append([count, prev])
#     return encoding
#
# lst = [9, 1, 2, 4, 3, 4.3, 5, 1]
# string = "marvelboss"
#
# print("List RLE:", run_length_encoding(lst))
# print("String RLE:", run_length_encoding(string.capitalize()))



# 5.
# encoded = [[2, 1], 2, 3, [2, 4], 5, 1]
#
# decoded = []
# for item in encoded:
#     if isinstance(item, list):
#         count, val = item
#         decoded.extend([val] * count)
#     else:
#         decoded.append(item)
#
# print("Decoded list:", decoded)



# 6.
# lst = [[4], [10], [1, 4, 3], [0, 1, 5, 3, 6, 7], [9, 11], [13, 14, 15, 17]]
# low, high = 13, 17
#
# filtered = [sublist for sublist in lst if all(low <= x <= high for x in sublist)]
# print("Filtered list:", filtered)


# 7.
# lst = ['boss', 3, 2, 4, 5, 'kumar']
#
# nums = [x for x in lst if isinstance(x, (int, float))]
# print("Max and Min:", (max(nums), min(nums)))


# 8.
# lst = ['string', 'list', 'exercises', 'practice', 'solution']
# length = 8
#
# result = [s for s in lst if len(s) == length]
# print(f"Strings of length {length}:", result)


# 9.
# def extract_repeats(lst, n):
#     result = []
#     count = 1
#     for i in range(1, len(lst)+1):
#         if i < len(lst) and lst[i] == lst[i-1]:
#             count += 1
#         else:
#             if count == n:
#                 result.append(lst[i-1])
#             count = 1
#     return result
#
# nums1 = [1, 1, 3, 4, 4, 5, 6, 6, 7]
# nums2 = [1, 2, 3, 4, 4, 4, 4, 5, 7, 7, 7, 7]
#
# print("lists1:", nums1)
# print("Extract 2 consecutive elements:", extract_repeats(nums1, 2))
# print("lists2:", nums2)
# print("Extract 4 consecutive elements:", extract_repeats(nums2, 4))


# 10.
# def consecutive_diff(lst):
#     return [lst[i] - lst[i-1] for i in range(1, len(lst))]
#
# lists1 = [1, 1, 3, 4, 4, 5, 6, 7]
# lists2 = [4, 5, 8, 9, 6, 10]
#
# print(consecutive_diff(lists1))
# print(consecutive_diff(lists2))


# 11.
# nested1 = [[1, 2, 3], [2, 4, 5], [1, 1, 1]]
# nested2 = [[1, 2, 3], [-2, 4, -5], [1, -1, 1]]
#
# def extract_column(nested, col_idx):
#     return [row[col_idx] for row in nested]
#
# print("Extract 1st column:", extract_column(nested1, 0))
# print("Extract 3rd column:", extract_column(nested2, 2))


#12.
# lst = [2, 3, 8, 4, 7, 9, 8, 2, 6, 5, 1, 6, 1, 2, 3, 4, 6, 9, 1, 2]
# indices = [0, 3, 5, 7, 10]
# values = [lst[i] for i in indices]
# print("Values at indices:", values)

#
# 13.
# x = [1,2,3,4,5,6,7,8,9,10]
# y = [2,4,6,8]
# result = [i for i in x if i not in y]
# print(result)



# 14.
# def diff(lst):
#     return [lst[i+1] - lst[i] for i in range(len(lst)-1)]
#
# list1 = [1,2,3,4,5,6,7,8,9,10]
# list2 = [3,6,9,12]
#
# print(diff(list1))
# print(diff(list2))


# 15.
# x = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
# y = [[12, 18, 23, 25, 45], [7, 11, 19, 24, 28], [1, 5, 8, 18, 15, 16]]
#
# intersection = [[i for i in sublist if i in x] for sublist in y]
# print(intersection)


# 16.
# x = [1,2,3,4,5,6,7]
# y = [10,20,30,40,50,60,70]
# z = [100,200,300,400,500,600,700]
#
# interleaved = [val for trio in zip(x,y,z) for val in trio]
# print(interleaved)


# 17.
# import random
#
# x = [1, 2, 7, 8, 3, 7]
# y = [4, 3, 8, 9, 4, 3, 8, 9]
#
# combined = x + y
# random.shuffle(combined)
#
# print("Random interleaved list:", combined)


# 18.
# from collections import Counter
#
# lists = [[1, 2, 3, 2], [4, 5, 6, 2], [7, 8, 9, 5]]
#
# flat = [item for sublist in lists for item in sublist]
# freq = dict(Counter(flat))
#
# print(freq)



# 19.
# lists = ['4', '12', '45', '7', '0', '100', '200', '-12', '-500']
#
# sorted_list = sorted(lists, key=int)
# print(sorted_list)



20.
lst = [1, 3, 5, 7, 4, 1, 6, 8]

first_even = next((x for x in lst if x % 2 == 0), None)
first_odd = next((x for x in lst if x % 2 != 0), None)

print((first_even, first_odd))



