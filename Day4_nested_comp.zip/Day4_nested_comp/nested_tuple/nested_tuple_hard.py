# 1.
# def average_nested_tuples(data):
#     return [sum(col) / len(col) for col in zip(*data)]
#
# data1 = ((10, 10, 10, 12), (30, 45, 56, 45), (81, 80, 39, 32), (1, 2, 3, 4))
# data2 = ((1, 1, -5), (30, -15, 56), (81, -60, -39), (-10, 2, 3))
#
# print(average_nested_tuples(data1))
# print(average_nested_tuples(data2))

# 2.
# def check_element(nested, elem):
#     return any(elem in t for t in nested)
#
# data = (('Red', 'White', 'Blue'), ('Green', 'Pink', 'Purple'), ('Orange', 'Yellow', 'Lime'))
#
# print(check_element(data, "White"))
# print(check_element(data, "Olive"))

# 3.
# def sum_each_tuple(lst):
#     return [sum(t) for t in lst]
#
# print(sum_each_tuple([(1, 2), (2, 3), (3, 4)]))
# print(sum_each_tuple([(1, 2, 6), (2, 3, -6), (3, 4), (2, 2, 2, 2)]))

# 4.
# x = (("boss", 10), ("suresh", 12), ("anand", 14), ("siva", 20), ("bala", 25), ("karthi", 30))
# converted = {v: k for k, v in x}
# print(converted)

# 5.
# data = [('GFG', 'IS', 'BEST'), ('GFg', 'AVERAGE'), ('GFG',), ('Gfg', 'CS')]
# result = [t for t in data if all(item.isupper() for item in t)]
# print(result)

# 6.
# t1 = ((1, 3), (4, 5), (2, 9), (1, 10))
# t2 = ((6, 7), (3, 9), (1, 1), (7, 3))
#
# result = tuple((max(a[0], b[0]), max(a[1], b[1])) for a, b in zip(t1, t2)
#                if isinstance(a, tuple) and isinstance(b, tuple))
# print(result)


# 7.
# t1 = ((13, 32), (33, 24), (53, 64), (14, 10))
# t2 = ((62, 17), (33, 94), (13, 41), (74, 43))
#
# result = tuple((max(a, b), max(c, d)) for (a, c), (b, d) in zip(t1, t2))
# print(result)

#
# 8.
# from itertools import product
#
# data = [([1, 2, 3], 'gfg'), ([5, 4, 3], 'cs')]
# result = [pair for group in data for pair in product(group[0], [group[1]])]
# print(result)

# 9.
# x = [('a', 0), ('b', 0), ('c', 0)]
# y = dict([('a', 5), ('c', 3)])
#
# result = [(k, y.get(k, v)) for k, v in x]
# print(result)

10.
data = [('baskar', 1), ('suresh', 2), ('is', 3), ('Placed', 4)]
unzipped = list(zip(*data))
print(unzipped)
