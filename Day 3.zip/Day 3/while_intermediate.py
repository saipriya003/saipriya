#1
# num = int(input("Please Enter any Positive Integer less than 5 : "))
#
# if num <= 0 or num >= 5:
#     print("Please enter a valid positive integer less than 5.")
# else:
#     print("Multiplication Table")
#     current = num
#     while current <= 5:
#         i = 1
#         while i <= 10:
#             print(f"{i}  *  {current}  =  {i * current}")
#             i += 1
#         print("===============")
#         current += 1


#2
# x = [10, 20, 30, 40, 50]
#
# i = 0
# total = 0
#
# while i < len(x):
#     print(x[i])
#     total += x[i]
#     i += 1
#
# print("Sum= ", total)


#3
# minimum = 21
# maximum = 30
#
# num = minimum
#
# while num <= maximum:
#     if num % 2 == 0:
#         print(num)
#     num += 1


#5
# import random
#
# number = random.randint(0, 10)
# chances = 3
#
# while chances > 0:
#     guess = int(input("Enter your guess:"))
#     if guess == number:
#         print("You win!")
#         break
#     chances -= 1
#
# if chances == 0:
#     print("You lose")

#6
# password = input("Input your password: ")
#
# if (len(password) >= 8 and
#     any(ch.isupper() for ch in password) and
#     any(ch.isdigit() for ch in password)):
#     print("Valid Password")
# else:
#     print("Not a Valid Password")

#7
# while True:
#     letter = input("Input a letter of the alphabet: ")
#     if len(letter) == 1 and letter.isalpha():
#         if letter.lower() in ['a', 'e', 'i', 'o', 'u']:
#             print(f"{letter} is a vowel.")
#         else:
#             print(f"{letter} is a consonant.")
#         break
#     else:
#         print("Please enter a single alphabet letter.")


#9
# terms = 7
# a, b = 0, 1
# count = 0
#
# print("Fibonacci sequence:")
#
# while count < terms:
#     print(a, end=" ")
#     a, b = b, a + b
#     count += 1
# print()


# 10
# x = 987654
# print("Given Number: ", x)
#
# reversed_num = 0
# num = x
#
# while num > 0:
#     remainder = num % 10
#     reversed_num = reversed_num * 10 + remainder
#     num = num // 10
#
# print("Reversed Number: ", reversed_num)


#11
# def digit_sum(n):
#     total = 0
#     while n > 0:
#         total += n % 10
#         n //= 10
#     return total
#
# # Example usage:
# print(digit_sum(892))  # Output: 19



#14
# num = int(input("Enter a number: "))
# factorial = 1
# n = num
#
# while n > 1:
#     factorial *= n
#     n -= 1
#
# print(factorial)


#15
# a = int(input("Enter the first number:"))
# b = int(input("Enter the second number:"))
#
# while b != 0:
#     a, b = b, a % b
#
# print(a)


#16
# num = int(input("Enter a number: "))
# total = 0
# n = num
#
# while n > 0:
#     total += n % 10
#     n //= 10
#
# print(total)



#17
# num = int(input("Enter a number: "))
# n = num
# factor = 2
#
# while factor <= n:
#     if n % factor == 0:
#         print(factor)
#         n //= factor
#     else:
#         factor += 1



#18
# x = int(input("Enter a number: "))
# count = 0
# num = x
#
# if num == 0:
#     count = 1
# else:
#     while num > 0:
#         num //= 10
#         count += 1
#
# print("Total digits are: ", count)



#20
data = [2, 3, 12, 5]

for num in data:
    print('*' * num)
