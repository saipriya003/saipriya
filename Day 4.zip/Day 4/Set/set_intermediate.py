'''1. Write a Python program to check if two given sets have no elements in common. Return True if no common element, False if has common elements.
    Data:
        a = {1,2,3,4}
        b = {4,5,6,7}
        c = {8}
    Expected Output:
        Compare a and b: False
        Compare a and c: True
        Compare b and c: True'''

# a = {1, 2, 3, 4}
# b = {4, 5, 6, 7}
# c = {8}
# print("Compare a and b:",a.isdisjoint(b))
# print("Compare a and c:",a.isdisjoint(c))
# print("Compare b and c:",b.isdisjoint(c))


'''2. Write a Python program to check if a given value is present in a set or not. 
    Data:
        {1, 4, 5, 6, 11, 80, 20, 23} 
    Expected Output:
        Test if 11 exists in nums: True
        Test if 6 is not in nums:  True
        Test if 7 exists in nums:  False'''

# nums = {1, 4, 5, 6, 11, 80, 20, 23}
# print("Test if 11 exists in nums:",11 in nums)
# print("Test if 6 is in nums:",6  in nums)
# print("Test if 7 exists in nums:",7 in nums)
'''3. Write a Python program to print the following output from the given list x, y using frozenset().
    Data:
        x =[1, 2, 3, 4, 5]
        y =[3, 4, 5, 6, 7]
    Expected Output:
        False
        frozenset({1, 2})
        frozenset({1, 2, 3, 4, 5, 6, 7})'''

# x =[1, 2, 3, 4, 5]
# y =[3, 4, 5, 6, 7]
# fs1 = frozenset(x)
# fs2 = frozenset(y)
# fs3 = fs1 & fs2
# fs4 = fs1 | fs2
# print(fs1 == fs2)
# print(f"frozenset {fs3}")
# print(f"frozenset {fs4}")

''' 4. Write a Python program to print the following output from given set x={5, 7}, y={3, 2}, z=set() find the Expected Output.
    Expected Output:
        {(8, 3), (7, 2), (10, 3), (9, 2)} '''

# x={5, 7}
# y={3, 2}
# z = set()
# for i in x:
#     for j in y:
#         z.add((i+j,j))
# print(z)


''' 5. Write a Python program to count the elements in a list until an element is a set.
    Data:
        x = [10,20,30,(10,20),40]
    Expected Output:
        2 '''


'''6. Write a Python program to multiply all the elements in a given set.
    Data:
        x = {4, 3, 2, 2, -1, 18}
    Expected Output:
        Original set : {2, 3, 4, 18, -1}
        Product - multiplying all the numbers of the said set: -432'''

# from functools import reduce
# import operator
#
# x = {4, 3, 2, 2, -1, 18}
# print("Original set:", x)
# product = reduce(operator.mul, x)
# print("Product:", product)


'''7. Write a Python program to compute element-wise sum of given sets.
    Data: 
        x = {1, 2, 3, 4}
        y = {3, 5, 2, 1}
        z = {2, 2, 3, 1}
    Expected Output:
        Original sets:
            {1, 2, 3, 4}
            {1, 2, 3, 5}
            {1, 2, 3}
        Element-wise sum of the said sets:
            {9, 3, 6}'''
x = {1, 2, 3, 4}
y = {3, 5, 2, 1}
z = {2, 2, 3, 1}

# Convert to sorted list to align element-wise
# x_l, y_l, z_l = sorted(x), sorted(y), sorted(z)
# min_len = min(len(x_l), len(y_l), len(z_l))
# element_wise_sum = {x_l[i] + y_l[i] + z_l[i] for i in range(min_len)}
#
# print("Element-wise sum of the sets:", element_wise_sum)

'''8. Write a Python program to sum of all counts in a collections.
    Data:
        x = {2, 2, 4, 6, 6, 8, 6, 10, 4}
    Expected Output:
        5'''
# from collections import Counter
#
# x = [2, 2, 4, 6, 6, 8, 6, 10, 4]
# counter = Counter(x)
# total_counts = sum(counter.values())
# print(total_counts)

'''9. Write a Python program to create a bytearray from a set.
    Data:
        x = {10, 20, 56, 35, 17, 99}
    Expected Output:
        35
        99
        10
        17
        20
        56'''

''' 10. Write a Python program to create the combinations of 3 digit combo to following given range(1000).
    Expected Output:
        999 '''
# x = {10, 20, 56, 35, 17, 99}
# b = bytearray(sorted(x))
# for byte in b:
#     print(byte)

'''11. Write a Python program to add two positive integers without using the '+' operator.
    Data:
        (2, 10)
        (10, -20)
        (-10, -20)
    Expected Output:
         12
        -10
        -30'''

# def add(a, b):
#     while b != 0:
#         carry = a & b
#         a = a ^ b
#         b = carry << 1
#     return a
#
# print(add(2, 10))
# print(add(10, -20))
# print(add(-10, -20))


''' 12. Write a Python program to find the digits which are absent in a given mobile number.
    Data:
        x = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    Expected Output:
        [1, 4, 5] '''

# all_digits = set(range(10))
# mobile_number = "9032167890"
# present = set(int(d) for d in mobile_number)
# absent = sorted(all_digits - present)
# print(absent)


''' 13. Write a Python program to compute the digit number of sum of two given integers.
    Data:
        (a, b)=(5, 7)
    Expected Output:
        2 '''
# a, b = 5, 7
# digit_count = len(str(a + b))
# print(digit_count)

'''14. Write a Python program to create set difference. 
    Data:
        x = {"apple", "orange", "mango", "kiwi"}
        y = {"orange", "mango", "watermelon"}
    Expected Output:
        Difference between x & y is : {'orange', 'mango'}
        Difference between x - z is : {'apple', 'kiwi'}'''

# x = {"apple", "orange", "mango", "kiwi"}
# y = {"orange", "mango", "watermelon"}
#
# print("Difference between x & y is:", x & y)
# print("Difference between x - y is:", x - y)


'''15. Write a Python program to find the difference between two given sets using difference() and - operator.
    Data:
        sn1 = {1, 2, 3, 4, 5}
        sn2 = {4, 5, 6, 7, 8}
    Expected Output:
        Difference of sn1 and sn2 using difference(): {1, 2, 3}
        Difference of sn2 and sn1 using difference(): {8, 6, 7}
        Difference of sn1 and sn2 using - operator: {1, 2, 3}
        Difference of sn2 and sn1 using - operator: {8, 6, 7}'''

# sn1 = {1, 2, 3, 4, 5}
# sn2 = {4, 5, 6, 7, 8}
#
# print("Difference of sn1 and sn2 using difference():", sn1.difference(sn2))
# print("Difference of sn2 and sn1 using difference():", sn2.difference(sn1))
# print("Difference of sn1 and sn2 using - operator:", sn1 - sn2)
# print("Difference of sn2 and sn1 using - operator:", sn2 - sn1)


'''16. Write a Python program to check whether a given set has no elements in common with another given set using isdisjoint().
    Data:
        {1, 2, 3}
        {4, 5, 6}
        {3}
    Expected Output:
        Check sn1 set has no elements in common with sn2 set:
        True
        Check sn1 set has no elements in common with sn3 set:
        False'''

# sn1 = {1, 2, 3}
# sn2 = {4, 5, 6}
# sn3 = {3}
#
# print("Check sn1 has no elements in common with sn2 set:", sn1.isdisjoint(sn2))
# print("Check sn1 has no elements in common with sn3 set:", sn1.isdisjoint(sn3))

'''17. Write a  Python Program to print the common letters present in the two given strings using set().
    Data:
        x = "Hello"
        y = "World"
    Expected Output:
        The common letters are:
            o
            l'''

# x = "Hello"
# y = "World"
#
# common = set(x.lower()) & set(y.lower())
# print("The common letters are:")
# for c in common:
#     print(c)


'''18. Write a  Python Program to display the letters which are in the first string but not in the second string using set(). 
    Data:
        x = "Hello"
        y = "World"
    Expected Output:
        The letters are:
            H
            e'''
# x = "Hello"
# y = "World"
#
# unique = set(x) - set(y)
# print("The letters are:")
# for c in unique:
#     print(c)

'''19. Write Python Program to display the letters which are not in common from both the given strings using set(). 
    Data:
        x = "Hello"
        y = "World"
    Expected Output:
        The letters are:
            W
            H
            d
            e
            r'''
# x = "Hello"
# y = "World"
#
# diff = set(x) ^ set(y)
# print("The letters are:")
# for c in diff:
#     print(c)

'''20. Write a Python program to check if a set is a subset of another set.
    Data:
        1:  {'green', 'blue'}
        2:  {'blue', 'red'}
        3:  {'blue'}
    Expected Output:
        If s1 is subset of s2: False
        If s1 is subset of s3: False
        If s2 is subset of s1: False
        If s2 is subset of s3: False'''


s1 = {'green', 'blue'}
s2 = {'blue', 'red'}
s3 = {'blue'}

print("If s1 is subset of s2:", s1.issubset(s2))
print("If s1 is subset of s3:", s1.issubset(s3))
print("If s2 is subset of s1:", s2.issubset(s1))
print("If s2 is subset of s3:", s2.issubset(s3))
