# 1 .Question | Write a program to print 15,5,2 and 0 ,use the approriate operator

a = 10
b = 5

# Your Answer
print(f"{a + b} , {a - b}, {a // b} , {a % b}")


# 2 .Question | write a code to print 9 , use the approriate operator
a = 3
b = 2

# Your Answer
result = a ** b
print(result)

# 4 .Question | # write a code to print 2 , 2.25 and 1 , use the approriate operator

x = 9
y = 4

# Your Answer
print(f"{x // y}, {x / y}, {x % y}")

# 5 .Question |  # write a code print True ,use the approriate operator

a = 10
b = 5

# Your Answer

# 5 .Question | # # write a code print False

a = 15
b = 15

# Your Answer
print(a != b)


# 6 .Question | # # write a code print True

a = 24
b = 24

# Your Answer
print(a == b)

# 7 .Question | # # write a code print True

a = "python"
b = "python"

# Your Answer
print(a == b)

# 8 .Question | #  write a code print false using and operator

a = 10
b = 20

# Your Answer
print(a > b and a == b)


# 9 .Question | #  write a code print True using or operator

a = 20
b = 10

# Your Answer
print(a > b or b < a)

# 10 .Question | #  write a code print True using Not operator

a = 20
b = 10

# Your Answer
print(not a > b)
