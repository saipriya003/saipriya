# Write a program to find given number is odd or even
# x = 45
#Your Answer
# if x % 2 == 0:
#     print("Even")
# else:
#     print("Odd")

#Write a program to find the given year is leap year or not
# year = 2020
# Your Answer
# if(year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
#     print(f"{year} is a leap year")
# else:
#     print(f"{year} is not a leap year")

# Write a program to print "You can Vote" or "You Cannot Vote

# age = int(input("Enter the age: "))
# if age >= 18:
#     print("Yes the person can vote")
# else:
#     print("No they are not eligible to vote")

# Write a program to find greatest of three numbers
# n1 = int(input(f"Enter n1: "))
# n2 = int(input(f"Enter n2: "))
# n3 = int(input(f"Enter n3: "))
# if n1 >= n2 and n1 >= n3:
#     largest = n1
# elif n2 >= n1 and n2 >= n3:
#     largest = n2
# else:
#     largest = n3
# print(f"The largest number is {largest}")

#Write a program to print "Super" if the sum of number is "less" than 1000 and
# "great" if the sum of number is greater than 1000

count = int(input("How many numbers do you want to add? : "))
total = 0
for i in range(count):
    number = int(input("Enter the number: "))
    total += number

if total < 1000:
    print("Super")
else:
    print("Great")




