'''1. Write a Python program to count the number of each character in a string.
    Data:
        "aidinasaur.com"
    Expected Output:
        {'a': 3, 'i': 2, 'd': 1, 'n': 1, 's': 1, 'u': 1, 'r': 1, '.': 1, 'c': 1, 'o': 1, 'm': 1}'''
from collections import Counter

# def count_characters(string):
#     char_count = {}
#     for char in string:
#         if char in char_count:
#             char_count[char] += 1
#         else:
#             char_count[char] = 1
#
#     print(f"{char_count}")
#
# input_string = input("Enter the character: ")
# count_characters(input_string)


'''2. Write a Python program to get a string made of the first 2 and the last 2 chars from a given a string. 
   If the string length is less than 2, return instead of the empty string.
    Data:
        'aidinasaur'
        'ai'
        'a'
    Expected Output:
        aiur
        aiai'''

# def function(s):
#     length = len(s)
#     if length < 2:
#         return ""
#     else:
#         return s[:2] + s[length-2:]
#
# input_string = input("Enter the string: ")
# res = function(input_string)
# print(res)



'''3. Write a Python program to get a string from a given string where all occurrences of its first char have been changed to '$',
   except the first char itself. 
    Data:
        'restart'
    Expected Output:
        resta$t'''

# def replace_occurrences_of_first_char_to_dollars(s):
#     first_char = s[0]
#     rest = s[1:].replace(first_char,'$')
#     return first_char + rest
#
# data = 'restart'
# res = replace_occurrences_of_first_char_to_dollars(data)
# print(res)


'''4. Write a Python program to get a single string from two given strings, separated by a space and swap 
   the first two characters of each string. 
    Data:
        'abc', 'xyz'
    Expected Output:
        xyc abz'''

# def swap_first_two_char(str1,str2):
#     new_str1 = str2[:2] + str1[2:]
#     new_str2 = str1[:2] + str2[2:]
#     return new_str1 + " " + new_str2
#
# string1 = input("Enter the string1: ")
# string2 = input("Enter the string2: ")
# res = swap_first_two_char(string1,string2)
# print(res)


'''5. Write a Python program to add 'ing' at the end of a given string (length should be at least 3).If the given string already 
   ends with 'ing' then add 'ly' instead.If the string length of the given string is less than 3, leave it unchanged.
    Data:
        'abc'
        'string'
    Expected Output:
        abcing
        stringly'''

# def word_ends_with(text):
#     if len(text) < 3:
#         return text
#     elif text.endswith("ing"):
#         return text + "ly"
#     else:
#         return text + "ing"
#
# Data = input("Enter the string: ")
# res = word_ends_with(Data)
# print(res)

'''7. Write a Python function that takes a list of words and returns the longest word and the length of the longest one.
    Data:
        Longest word: Exercises
    Expected Output:
        Length of the longest word: 9'''

# def find_logest_word(word_list):
#      if not word_list:
#          return 0
#      longest = max(word_list, key=len)
#      return longest, len(longest)
#
# words = ["Exercises", "math", "kiwi","segryu"]
# longest_word,length = find_logest_word(words)
# print(longest_word)
# print(f"The length of the longest word: {length}")

'''8. Write a Python program to count the occurrences of each word in a given sentence.
    Data:
        'Read and edit documents attached to emails'
    Expected Output:
        {'Read': 1, 'and': 1, 'edit': 1, 'documents': 1, 'attached': 1, 'to': 1, 'emails': 1}'''

# def count_word_occurrences(sentence):
#      sentence = sentence.lower()
#      words = sentence.split()
#      word_count = {}
#      for word in words:
#          word_count[word] = word_count.get(word, 0) + 1
#          return word_count
#
#
# sen = 'Read and edit documents attached to emails'
# res = count_word_occurrences(sen)
# print(res)


'''9. Write a Python function to convert a given string to all uppercase if it contains at least 2 uppercase 
   characters in the first 4 characters.
    Data:
        'Python'
        'PyThon'
    Expected Output:
        Python
        PYTHON '''

#
# def convert_if_uppercase(s):
#     count = sum(1 for c in s[:4] if c.isupper())
#     if count >= 2:
#         return s.upper()
#     else:
#         return s
# data = input("Enter the string: ")
# res = convert_if_uppercase(data)
# print(res)

'''10. Write a Python program to print the following floating numbers upto 2 decimal places.
    Data:
        x = 3.1415926
        y = 12.9999
    Expected Output:
        Formatted Number: 3.14
        Formatted Number: 13.00'''

# x = 3.1415926
# y = 12.9999
# print("Formatted Number: {:.2f}".format(x))
# print("Formatted Number: {:.2f}".format(y))


'''11. Write a Python program to print the following floating numbers upto 2 decimal places with a sign.
    Data:
        x = 3.1415926 
        y = -12.9999
    Expected Output:
        Formatted Number with sign: +3.14
        Formatted Number with sign: -13.00'''

# x = 3.1415926
# y = -12.9999
# print("Formatted Number with sign: {:.2f}".format(x))
# print("Formatted Number with sign: {:.2f}".format(y))


'''12. Write a Python program to print the following floating numbers with no decimal places.
    Data:
        x = 3.1415926
        y = -12.9999
    Expected Output:
        Formatted Number with no decimal places: 3
        Formatted Number with no decimal places: -13'''

# x = 3.1415926
# y = -12.9999
# print("Formatted Number with no decimal places: {:.0f}".format(x))
# print("Formatted Number with no decimal places: {:.0f}".format(y))


'''13. Write a Python program to print the following integers with zeros on the left of specified width.
    Data:
        x = 3
        y = 123
    Expected Output:
        Formatted Number(left padding, width 2): 03
        Formatted Number(left padding, width 6): 000123'''

# x = 3
# y = 123
# print("Formatted Number(left padding, width 2): {:02d}".format(x))
# print("Formatted Number(left padding, width 6): {:06d}".format(y))


'''14. Write a Python program to print the following integers with '*' on the right of specified width.
    Data:
        x = 3
        y = 123
    Expected Output:
        Formatted Number(right padding, width 2):  3*
        Formatted Number(right padding, width 6):  123***'''

# x = 3
# y = 123
# print("Formatted Number(right padding, width 2): {:<2}*".format(x))
# print("Formatted Number(right padding, width 6): {:<6}*".format(y))

'''15. Write a Python program to display a number with a comma separator.
    Data:
        x = 3000000
        y = 30000000
    Expected Output:
        Formatted Number with comma separator: 3,000,000
        Formatted Number with comma separator: 30,000,000'''

# x = 3000000
# y = 30000000
# print("Formatted Number with comma separator: {:,}".format(x))
# print("Formatted Number with comma separator: {:,}".format(y))



'''16. Write a Python program to format a number with a percentage.
    Data:
        x = 0.25
        y = -0.25
    Expected Output:
        Formatted Number with percentage: 25.00%
        Formatted Number with percentage: -25.00%'''

# x = 0.25
# y = -0.25
# print("Formatted Number with percentage: {:.2%}".format(x))
# print("Formatted Number with percentage: {:.2%}".format(y))

'''17. Write a Python program to reverse words in a string.
    Data:
        "Read and edit documents attached to emails."
        "Python Exercises."
    Expected Output:
        emails. to attached documents edit and Read
        Exercises. Python'''

# def reverse_words(sentence):
#     return ' '.join(sentence.split()[::-1])
# s1 = "Read and edit documents attached to emails."
# s2 = "Python Exercises."
#
# print(reverse_words(s1))
# print(reverse_words(s2))

'''18. Write a Python program to strip vowels from a given string.
    Data:
        Original String:
        "Read and edit documents attached to emails."
    Expected Output:
        After stripping a,e,i,o,u
        Rd nd dt dcmnts ttchd t mls.'''

# def strip_vowels(text):
#     vowels = "aeiouAEIOU"
#     return ''.join(char for char in text if char not in vowels)
#
# original = "Read and edit documents attached to emails."
# print("After stripping a,e,i,o,u")
# print(strip_vowels(original))


'''19. Write a Python program to count repeated characters in a string.
    Data:
        string: 'thequickbrownfoxjumpsoverthelazydog'
    Expected Output:
        o 4
        e 3
        t 2
        h 2
        u 2
        r 2'''

# from collections import Counter
# s = 'thequickbrownfoxjumpsoverthelazydog'
# count = Counter(s)
#
# # Print characters with count > 1, sorted by first occurrence in string
# printed = set()
# for char in s:
#     if count[char] > 1 and char not in printed:
#         print(char, count[char])
#         printed.add(char)

'''20. Write a Python program to print the square and cube symbol in the area of a rectangle and volume of a cylinder.
    Data:
        area = 1256.66
        volume = 1254.725
    Expected Output:
        The area of the rectangle is 1256.66cm2
        The volume of the cylinder is 1254.725cm3'''


area = 1256.66
volume = 1254.725
square = "\u00B2"
cube = "\u00B3"

print(f"The area of the rectangle is {area}cm{square}")
print(f"The volume of the cylinder is {volume}cm{cube}")
