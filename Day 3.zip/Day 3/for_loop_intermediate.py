''' 1. Write a Python function to count the no. of occurances of 4 from the data given below.
    Data:
        [1, 4, 6, 7, 4]
        [1, 4, 6, 4, 7, 4]
    Expected Output:
        2
        3 '''

# def count_fours(lst):
#     return lst.count(4)
# data1 = [1, 4, 6, 7, 4]
# data2 = [1, 4, 6, 4, 7, 4]
# print(count_fours(data1))
# print(count_fours(data2))


''' 2. Write a Python function to check whether the specified value is present in the list. Return True if present, false if not.
        Data :
            3 -> [1, 5, 8, 3]    
           -1 -> [1, 5, 8, 3] 
        Expected Output:
            True
            False '''

# def is_present(value, lst):
#     return value in lst
# print(is_present(3, [1, 5, 8, 3]))
# print(is_present(-1, [1, 5, 8, 3]))


''' 3. Write a Python function to create a histogram using the given data.
        Data:
            [2, 3, 12, 5]
        Expected Output:
            **
            ***
            ************
            ***** '''

# def create_histogram(data):
#     for num in data:
#         print('*' * num)
# data = [2, 3, 12, 5]
# create_histogram(data)


''' 4. Write a Python function to concatenate all elements in a list into a string and return it. 
        Data:
            [1, 5, 12, 2]
        Expected Output:
            15122 '''

# def concatenate_list_elements(lst):
#     return ''.join(str(i) for i in lst)
# data = [1, 5, 12, 2]
# print(concatenate_list_elements(data))


''' 5. Write a Python program to print * without newline or space using for loop and range().
        Expected Output:
            ********** '''

# for _ in range(10):
#     print('*', end='')
#
# print()


''' 6. Write a python function to print the sum of digits for the given data and print the execution time (in seconds).
        Data:
            n = 5
        Expected Output:
            Time to sum of 1 to 5 and required time to calculate is : (15, 0.0) '''

# import time
# def sum_and_time(n):
#     start = time.time()
#     total = sum(range(1, n+1))
#     end = time.time()
#     duration = end - start
#     print(f"Time to sum of 1 to {n} and required time to calculate is : ({total}, {duration})")
# n = 5
# sum_and_time(n)


''' 7. Write a Python program to hash a word.
        Data:
            x = [0,1,2,3,0,1,2,0,0,2,2,4,5,5,0,1,2,6,2,3,0,1,0,2,0,2]
            word = Input the word be hashed: rfdf
        Expected Output:
            Enter the word to be hashed: culture
            The coded word is: C210220 '''


''' 8. Write a Python program to create a bytearray from the given list.
        Data:
            x = [10, 20, 56, 35, 17, 99]
        Expected Output:
            10
            20
            56
            35
            17
            99 '''

# x = [10, 20, 56, 35, 17, 99]
# b = bytearray(x)
# for byte in b:
#     print(byte)

''' 9. Write a Python program to calculate the time runs (difference between start and current time) of a program.
        Data:
            times(5)
            times(4)
        Expected Output:
            0
            1
            2
            3
            4
            0.003652000000101907
            0
            1
            2
            3
            0.0070380999998178595 '''
# import time
# def times(n):
#     start = time.time()
#     for i in range(n):
#         print(i)
#         time.sleep(1)
#     end = time.time()
#     print(end - start)
# times(5)
# times(4)

''' 10. Write a Python function to find the maximum and minimum numbers from the given list.
        Data:
            seq = [0, 10, 15, 40, -5, 42, 17, 28, 75]
        Expected Output:
            (75, -5) '''

# def find_max_min(seq):
#     return (max(seq), min(seq))
# seq = [0, 10, 15, 40, -5, 42, 17, 28, 75]
# print(find_max_min(seq))


''' 11. Write a Python function to find a distinct pair of numbers whose product is odd from the given data. Print True if pair found, none if not.
        Data:
            x = [2, 4, 6, 8]
            y = [1, 6, 4, 7, 8]
        Expected Output:
            None
            True '''


# def has_odd_product_pair(lst):
#     odds = [n for n in lst if n % 2 != 0]
#
#     return True if len(odds) >= 2 else None
#
# x = [2, 4, 6, 8]
# y = [1, 6, 4, 7, 8]
#
# print(has_odd_product_pair(x))
# print(has_odd_product_pair(y))

''' 12. Write a Python program to create the combinations of 3 digit combo.
        Expected Output:
            999 '''

# from itertools import product
# combinations = [''.join(map(str, combo)) for combo in product(range(10), repeat=3)]
# print(combinations[-1])  # Expected: 999


''' 13. Write a Python program to create all possible permutations from a given collection of distinct numbers.
        Data:
            Collection:  [1, 2, 3]
        Expected Output:
            Collection of distinct numbers: [[3, 2, 1], [2, 3, 1], [2, 1, 3], [3, 1, 2], [1, 3, 2], [1, 2, 3]] '''

# from itertools import permutations
# collection = [1, 2, 3]
# perm_list = [list(p) for p in permutations(collection)]
# perm_list.reverse()
# print("Collection of distinct numbers:", perm_list)


''' 14. Write a Python program to find the number of notes (Sample of notes: 10, 20, 50, 100, 200 and 500).
        Data:
            880
            1000
        Expected Output:
            6
            2 '''

# def count_notes(amount):
#     notes = [500, 200, 100, 50, 20, 10]  # descending order
#     count = 0
#     for note in notes:
#         if amount >= note:
#             note_count = amount // note
#             count += note_count
#             amount %= note
#     return count
# print(count_notes(880))
# print(count_notes(1000))

''' 15. Write a Python function to find the number of divisors of a given integer is even or odd.
        Data:
            x = 15, x = 12, x = 9, x = 6, x = 3
        Expected Output:
            4
            6
            3
            4
            2 '''

# def count_divisors(x):
#     count = 0
#     for i in range(1, x + 1):
#         if x % i == 0:
#             count += 1
#     return count
#
# print(count_divisors(15))
# print(count_divisors(12))
# print(count_divisors(9))
# print(count_divisors(6))
# print(count_divisors(3))


''' 16. Write a Python function to get the smallest number from a list.
        Data:
            smallest([1, 2, -8, 0])
        Expected Output:
            -8 '''

# def smallest(numbers):
#     return min(numbers)
# print(smallest([1, 2, -8, 0]))


''' 17. Write a Python function to get the largest number from a list.
        Data:
            largest([1,2,-8,0])
        Expected Output:
            2 '''

# def largest(numbers):
#     return max(numbers)
# print(largest([1, 2, -8, 0]))

''' 18. Write a Python function to multiply all the items in a list.
        Data:
            list = [1, 2, -8]
        Expected Output:
            -16 '''

# def multiply_list(items):
#     result = 1
#     for item in items:
#         result *= item
#     return result
# print(multiply_list([1, 2, -8]))

''' 19. Write a Python function to sum all the items in a list.
        Data:
            lists([1,2,-8])
        Expected Output:
            -5 '''

# def lists(numbers):
#     return sum(numbers)
# print(lists([1, 2, -8]))

''' 20. Write a Python program to remove duplicates from the data given below.
        Data:
            a = [10,20,30,20,10,50,60,40,80,50,40]
        Expected Output:
            [10, 20, 30, 50, 60, 40, 80] '''

a = [10, 20, 30, 20, 10, 50, 60, 40, 80, 50, 40]

def remove_duplicates(lst):
    seen = set()
    result = []
    for item in lst:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result

print(remove_duplicates(a))
