# Read Five marks kannada,english,maths,science and social and if all marks are greater than
# 35 , print pass else print fail

kannada = int(input("Enter the marks obtained in kannada: "))
english = int(input("Enter the marks obtained in english: "))
math = int(input("Enter the marks obtained in math: "))
science = int(input("Enter the marks obtained in science: "))
social = int(input("Enter the marks obtained in social: "))
if kannada > 35:
    if english > 35:
        if math > 35:
            if science > 35:
                if social > 35:
                    print("Pass")
                else:
                    print("Failed in social")
            else:
                print("Failed in science")
        else:
            print("Failed in maths")
    else:
        print("Failed in english")
else:
    print("Failed in kannada")


