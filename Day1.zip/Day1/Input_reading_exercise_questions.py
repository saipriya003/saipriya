# Write a program to hours to minutes , user should able to give hours as input
from warnings import simplefilter

# # your Answer
# hours = int(input("Enter the number of hours: "))
# minutes = hours * 60
# print(f"{hours} equals to {minutes} minutes")

# Write a program to convert centimeter to meter , user should be able to give centimeter as input

# your Answer
# centimeter = int(input("Enter the centimeter: "))
# meters = centimeter / 100
# print(f"The meter for above equivalent centimeter is {meters} m")

# Write a program to convert miles to Kilometer , user shoulb be able to give miles as input

# your Answer
# miles = int(input("Enter the miles: "))
# kilometers = miles * 1.60
# print(f"The equivalent kilometer for miles is {kilometers} km")

# Write a program to convert pounds to Kilogram , user should be able to give pounds as input

# your Answer
# pounds = float(input("Enter the weight of pounds: "))
# kilograms = pounds * 0.453592
# print(f"Weight of kilograms is {kilograms} kg")

# Write a program to calculate simple interest # all input should be given by the user

# your Answer
# principal_amount = int(input("Enter P in Rs: "))
# rate_of_interest = int(input("Enter R in %:"))
# time = int(input("Enter time in years:"))
# Simple_interest = (principal_amount * rate_of_interest * time) / 100
# print(f"The SI is Rs.{Simple_interest}")

# Write a program to calculate area of circle

# your Answer
# radius = float(input("Enter the radius: "))
# area = 3.14 * radius ** 2
# print(f"Area of a circle is {area} cm")

# Write a program to calculate circumference of circle

# your Answer
# radius = float(input("Enter the radius: "))
# circumference = 2 * 3.14 * radius
# print(f"Circumference of the circle is {circumference}")

# Write a program to calculate perimeter of square

# your Answer
# side = float(input("Enter the length of one side of the square : "))
# perimeter = 4 * side
# print(f"The perimeter of a square is {perimeter}")

# Write a program to calculate area of square

# your Answer
# side = float(input("Enter the length of one side of the square: "))
# area = side * side
# print(f"Area of the square is {area}")

# Write a program to area of traingle

# your Answer
base = float(input("Enter the base of the triangle : "))
height = float(input("Enter the height of the triangle : "))
area = 0.5 * base * height
print(f"Area of triangle is {area}")






