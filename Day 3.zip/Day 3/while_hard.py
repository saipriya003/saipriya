#1
# def gcd(a, b):
#     while b != 0:
#         a, b = b, a % b
#     return a
#
# def lcm(a, b):
#     return abs(a * b) // gcd(a, b)
#
# # Test cases
# print(lcm(4, 6))   # Output: 12
# print(lcm(15, 17)) # Output: 255



#2
# def sum_of_cubes(n):
#     total = 0
#     i = 1
#     while i < n:
#         total += i ** 3
#         i += 1
#     return total
#
# # Example usage:
# print("Sum of cubes: ", sum_of_cubes(3))  # Output: 9



#3
# nums = [10, 20, 30, 40, 50, 60, 70, 80, 90]
#
# index = 2  # since list is 0-based, 3rd element is at index 2
#
# while nums:
#     # Remove and print the element at current index
#     print(nums.pop(index))
#     if not nums:
#         break
#     # Move index 2 steps ahead (because after removing one element, list shrinks)
#     index = (index + 2) % len(nums)



#5
# def find_n(s):
#     power = 1
#     concatenated = ""
#     while len(concatenated) < len(s):
#         concatenated += str(2 ** power)
#         power += 1
#     if concatenated == s:
#         return power - 1
#     else:
#         return -1  # if no exact match
#
# # Test cases
# print(find_n("2481632"))    # Output: 5
# print(find_n("248163264"))  # Output: 6



#6
# def sum_of_digits(n):
#     total = 0
#     while n > 0:
#         total += n % 10
#         n //= 10
#     return total
#
# def process_number(num):
#     while num > 0:
#         prev = num
#         num = num - sum_of_digits(num)
#     return prev
#
# # Test cases
# print(process_number(9))
# print(process_number(21))



#7
# def sum_abs_diff(arr):
#     total = 0
#     i = 0
#     n = len(arr)
#     while i < n:
#         j = i + 1
#         while j < n:
#             total += abs(arr[j] - arr[i])
#             j += 1
#         i += 1
#     return total
#
# # Test cases
# print(sum_abs_diff([1, 2, 3]))  # Output: 4
# print(sum_abs_diff([1, 4, 5]))  # Output: 8



#8
# def common_divisors_count(a, b):
#     count = 0
#     i = 1
#     limit = min(a, b)
#     while i <= limit:
#         if a % i == 0 and b % i == 0:
#             count += 1
#         i += 1
#     return count
#
# # Test data
# pairs = [(2, 4), (2, 8), (12, 24)]
#
# for a, b in pairs:
#     print("Number of common divisors: ", common_divisors_count(a, b))


#9
# def is_palindrome(num):
#     return str(num) == str(num)[::-1]
#
# def reverse_number(num):
#     return int(str(num)[::-1])
#
# def reverse_add_until_palindrome(num):
#     while not is_palindrome(num):
#         rev = reverse_number(num)
#         num = num + rev
#     return num
#
# # Test cases
# print(reverse_add_until_palindrome(1234))  # Output: 5555
# print(reverse_add_until_palindrome(1473))  # Output: 9339
# print(reverse_add_until_palindrome(121))   # Output: 121
