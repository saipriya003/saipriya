#1Q:
# x = [(1, 2), (3, 4), (8, 9)]
# unzipped = list(zip(*x))
# print(unzipped)


#2Q:
# x = (10, 20, 30)
# print(f"This is a tuple {x}")


#3Q:
    # x = [(80, 60, 40), (40, 90, 60), (20, 40, 90)]
    # x = [t[:-1] + (100,) for t in x]
    # print(x)


#4Q:
# X = [(), (), ('',), ('a', 'b'), ('c', 'd', 'e'), ('f')]
# X = [i for i in X if i != ()]
# print(X)


#5Q:
# x = [('item1', '29.20'), ('item2', '49.10'), ('item3', '33.5')]
# x.sort(key=lambda i: float(i[1]), reverse=True)
# print(x)


#6Q:
# x = [10, 20, 30, (10, 20), 40]
# count = 0
# for i in x:
#     if isinstance(i, tuple):
#         break
#     count += 1
# print


#7Q:
# x = (('a', 23), ('b', 37), ('c', 11), ('d', 29))
# sorted_x = tuple(sorted(x, key=lambda i: i[1]))
# print(sorted_x)


#8Q:
# y = (45, 45, 45, 45)
# print(all(i == y[0] for i in y))


#9Q:
# a = (5,)
# area = 3.14 * a[0] ** 2
# print(area)


#10Q:
# a = (2,)
# pi = 3.141592653589793
# circumference = 2 * pi * a[0]
# print(circumference)


#11Q:
# a = (3,)
# perimeter = 4 * a[0]
# print(perimeter)


#12Q:
# h = (23,)
# b = (34,)
# area = 0.5 * h[0] * b[0]
# print(area)


#13Q:
# print(())
# print((1, 2, 3))
# print((1, 'Hello', 3.4))
# print(('HI', [8, 4, 6], (1, 2, 3)))



#14Q:
# x = 3, 4.6, "dog"
# a, b, c = x
# print(x)
# print(a)
# print(b)
# print(c)


#15Q:
# x = (4, 2, 3, [6, 5])
# x[3][0] = 9
# print(x)


#16Q:
# x = ("Bihar", "Odisha", "Assam")
# if "Bihar" in x:
#     print("yes Bihar is present in the given tuple")
# for item in x:
#     print(item)


#17Q:
# x = ("Bihar", "Odisha", "Assam")
# print("Delhi" in x)
# print("Delhi" not in x)



#18Q:
# if (5 > 3 and 5 < 10):
#     print("Both statements are True")
# if (5 > 3 or 5 > 10):
#     print("any one statements are True")


#19Q:
# x = ("boss", "bala", "suresh")
# print(x[1])
# print(x[-1])


#20Q:
x = ("Magnum", "Pistah", "Strawberry", "Vennila", "Chocobar", "Blackberry", "Salad")
print(x[2:7])
print(x[3:-1])




