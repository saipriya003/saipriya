''' 1. Write a Python program to compute the greatest common divisor (GCD) of two positive integers.
    Data:
        gcd(22, 27)
        gcd(4, 3344)
    Expected Output:
        1
        4 '''
# def gcd(a, b):
#     greatest = 1
#     for i in range(1, min(a, b) + 1):
#         if a % i == 0 and b % i == 0:
#             greatest = i
#     return greatest
#
# print(gcd(22, 27))
# print(gcd(4, 3344))


''' 2. Write a Python program to get the least common multiple (LCM) of two positive integers.
    Data:
        lcm(4, 6)
        lcm(15, 27)
    Expected Output:
        12
        135 '''

# def lcm(a, b):
#     max_val = max(a, b)
#     for i in range(max_val, a * b + 1):
#         if i % a == 0 and i % b == 0:
#             return i
#
# print(lcm(4, 6))
# print(lcm(15, 27))


''' 3. Write a Python program to find the list of words that are longer than a specified number from the given list.
    Data:
        lt = ["The Read and edit documents attached to emails"]
        number = 3
    Expected Output:
        ['Read', 'edit', 'documents', 'attached', 'emails'] '''

# lt = ["The Read and edit documents attached to emails"]
# number = 3
# words = lt[0].split()
# result = []
# for word in words:
#     if len(word) > number:
#         result.append(word)
# print(result)

''' 4. Write a Python function that takes two lists as parameters and returns True if they have at least one element in common, none if not.
    Data:
        (a, b) = ([1,2,3,4,5], [5,6,7,8,9])
        (a, b) =([1,2,3,4,5], [6,7,8,9])
    Expected Output:
        True
        None '''

# def common_element(a, b):
#     for element in a:
#         if element in b:
#             return True
#     return None
# print(common_element([1,2,3,4,5], [5,6,7,8,9]))
# print(common_element([1,2,3,4,5], [6,7,8,9]))


''' 5. Write a Python program to generate all sublists of a list.
    Data:
        Original list:
        x = [10, 20, 30, 40]
        y = ['X', 'Y', 'Z']
    Expected Output:
        Sublists of the said list:
        [[], [1], [2], [1, 2], [3], [1, 3], [2, 3], [1, 2, 3]]
        [[], ['x'], ['y'], ['x', 'y'], ['z'], ['x', 'z'], ['y', 'z'], ['x', 'y', 'z']] '''

# def all_sublists(lst):
#     sublists = [[]]
#     for element in lst:
#         # For each element, add it to existing sublists to form new sublists
#         new_sublists = []
#         for sublist in sublists:
#             new_sublists.append(sublist + [element])
#         sublists.extend(new_sublists)
#     return sublists
#
# x = [1, 2, 3]
# y = ['x', 'y', 'z']
# print(all_sublists(x))
# print(all_sublists(y))


''' 6. Write a Python program to print all the prime numbers upto a specified number using Sieve of Eratosthenes method.
    Data:
        x = 10
    Expected Output:
        2
        3
        5
        7
        None '''

# def sieve_of_eratosthenes(x):
#     if x < 2:
#         return None
#
#     primes = [True] * (x + 1)
#     primes[0], primes[1] = False, False
#
#     for i in range(2, int(x ** 0.5) + 1):
#         if primes[i]:
#             for j in range(i * i, x + 1, i):
#                 primes[j] = False
#
#     found_prime = False
#     for i in range(2, x + 1):
#         if primes[i]:
#             print(i)
#             found_prime = True
#
#     if not found_prime:
#         print(None)
#     return None
#
# x = 10
# sieve_of_eratosthenes(x)

''' 7. Write a Python program to generate the combinations of n distinct objects taken from the elements of a given list..
    Data:
        Original list:
        [1, 2, 3, 4, 5, 6, 7, 8, 9]
    Expected Output:
        [1, 2][1, 3][1, 4][1, 5][1, 6][1, 7][1, 8][1, 9][2, 3]
        [2, 4][2, 5][2, 6][2, 7][2, 8][2, 9][3, 4][3, 5][3, 6]
        [3, 7][3, 8][3, 9][4, 5][4, 6][4, 7][4, 8][4, 9][5, 6]
        [5, 7][5, 8][5, 9][6, 7][6, 8][6, 9][7, 8][7, 9][8, 9] '''

# lst = [1, 2, 3, 4, 5, 6, 7, 8, 9]
# for i in range(len(lst)):
#     for j in range(i + 1, len(lst)):
#         print([lst[i], lst[j]], end='')


''' 8. Write a Python program to create a multidimensional list (lists of lists) with zeros.
    Expected Output:
        Multidimensional list:
        [[0, 0], [0, 0], [0, 0]] '''
# rows = 3
# cols = 2
# multi_list = []
# for _ in range(rows):
#     row = []
#     for _ in range(cols):
#         row.append(0)
#     multi_list.append(row)
# print("Multidimensional list:")
# print(multi_list)

''' 9. Write a Python program to create a 3X3 grid with numbers following given range(3). 
    Expected Output:
        3X3 grid with numbers:
        [[1, 2, 3], [1, 2, 3], [1, 2, 3]] '''
# n = 3
# grid = []
# for _ in range(n):
#     row = []
#     for num in range(1, n + 1):
#         row.append(num)
#     grid.append(row)
# print("3X3 grid with numbers:")
# print(grid)

''' 10. Write a Python program to print the sum of each column in a matrix. Accept matrix rows, 
            columns and elements for each column separated with a space for every row as input from the user.
    Data:
        Input rows: 3
        Input columns: 3
        Input number of elements in a row (1, 2, 3): 
        2 2 2
        3 3 3
        4 4 4
    Expected Output:
        sum for each column:
        9  9  9  '''

''' 11. Write a Python program to count the number of sublists that contains a particular element.
    Data:
        Original list:
        [[1, 3], [5, 7], [1, 11], [1, 15, 7]]
    Expected Output:
        Count 1 in the said list: 3
        Count 7 in the said list: 2 '''
# def count_element_in_sublists(lst, element):
#     count = 0
#     for sublist in lst:
#         if element in sublist:
#             count += 1
#     return count
#
# original_list = [[1, 3], [5, 7], [1, 11], [1, 15, 7]]
# print("Count 1 in the said list:", count_element_in_sublists(original_list, 1))
# print("Count 7 in the said list:", count_element_in_sublists(original_list, 7))

''' 12. Write a Python program to count integer in a given mixed list.
    Data:
        list:[1, 'abcd', 3, 1.2, 4, 'xyz', 5, 'pqr', 7, -5, -12.22]
    Expected Output:
        Number of integers in the said mixed list:
        6 '''
# mixed_list = [1, 'abcd', 3, 1.2, 4, 'xyz', 5, 'pqr', 7, -5, -12.22]
# count = 0
# for item in mixed_list:
#     if isinstance(item, int):
#         count += 1
# print("Number of integers in the said mixed list:")
# print(count)

''' 13. Write a Python program to find an element with maximum occurrences in a given list. 
    Data:
        list:[2, 3, 8, 4, 7, 9, 8, 2, 6, 5, 1, 6, 1, 2, 3, 4, 6, 9, 1, 2]
    Expected Output:
        Item with maximum occurrences of the said list:
        2 '''
# lst = [2, 3, 8, 4, 7, 9, 8, 2, 6, 5, 1, 6, 1, 2, 3, 4, 6, 9, 1, 2]
# max_count = 0
# max_item = None
# for item in lst:
#     count = lst.count(item)
#     if count > max_count:
#         max_count = count
#         max_item = item
# print("Item with maximum occurrences of the said list:")
# print(max_item)

''' 14. Write a Python program to remove those items which contain a special character or specified string from the given list.
    Data:
        list1: ['Red color', 'Orange#', 'Green', 'Orange @', 'White']
    Expected Output:
        Character list:
        ['#', 'color', '@']

        New list:
        ['Red', '', 'Green', 'Orange', 'White'] '''

# list1 = ['Red color', 'Orange#', 'Green', 'Orange @', 'White']
# remove_list = ['#', 'color', '@']
# print("Character list:")
# print(remove_list)
# new_list = []
# for item in list1:
#     new_item = item
#     for element in remove_list:
#         new_item = new_item.replace(element, '')
#     new_list.append(new_item.strip())
# print("\nNew list:")
# print(new_list)

''' 15. Write a Python program to calculate the sum of the numbers in a list between the specified range of indices.
    Data:
        list:[2, 1, 5, 6, 8, 3, 4, 9, 10, 11, 8, 12]
    Expected Output:
        Range: 8 , 10
        Sum of the specified range: 29 '''

# list1 = [2, 1, 5, 6, 8, 3, 4, 9, 10, 11, 8, 12]
#
# start_index = 8
# end_index = 10
# print("Range:", start_index, ",", end_index)
# range_sum = 0
# for i in range(start_index, end_index + 1):
#     range_sum += list1[i]
# print("Sum of the specified range:", range_sum)


''' 16. Write a Python program to reverse each list in a given list of lists.
    Data:
        Original list of lists:
        nums = [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]] 
    Expected Output:
        Reverse each list in the said list of lists:
        [[4, 3, 2, 1], [8, 7, 6, 5], [12, 11, 10, 9], [16, 15, 14, 13]] '''

# nums = [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]]
#
# print("Reverse each list in the said list of lists:")
# reversed_lists = []
# for sublist in nums:
#     reversed_lists.append(sublist[::-1])
# print(reversed_lists)


''' 17. Write a Python program to find the difference between two lists including duplicate elements.
    Data:
        Original lists:
        x = [1,1,2,3,3,4,4,5,6,7]
        y = [1,1,2,4,5,6]
    Expected Output:
        Difference between two said list (including duplicate elements):
        [3, 3, 4, 7] '''
# x = [1, 1, 2, 3, 3, 4, 4, 5, 6, 7]
# y = [1, 1, 2, 4, 5, 6]
#
# print("Difference between two said list (including duplicate elements):")
# diff = []
# y_copy = y.copy()
# for item in x:
#     if item in y_copy:
#         y_copy.remove(item)
#     else:
#         diff.append(item)
# print(diff)

''' 18. Write a Python program to print consecutive elements pairing from the given list. 
    Data:
        Original lists:
        lists:[1, 1, 2, 3, 3, 4, 4, 5]
    Expected Output:
        Pairing of consecutive elements:
        [(1, 1), (1, 2), (2, 3), (3, 3), (3, 4), (4, 4), (4, 5)] '''

# lists = [1, 1, 2, 3, 3, 4, 4, 5]
#
# print("Pairing of consecutive elements:")
# pairs = []
# for i in range(len(lists) - 1):
#     pairs.append((lists[i], lists[i + 1]))
# print(pairs)

''' 19. Write a Python program to remove duplicate words from the given list of strings.
    Data:
        Original String:
        ['Python', 'Exercises', 'Practice', 'Solution', 'Exercises']
    Expected Output:
        After removing duplicate words from the said list of strings:
        ['Python', 'Exercises', 'Practice', 'Solution'] '''

# words = ['Python', 'Exercises', 'Practice', 'Solution', 'Exercises']
#
# print("After removing duplicate words from the said list of strings:")
#
# unique_words = []
# for word in words:
#     if word not in unique_words:
#         unique_words.append(word)
#
# print(unique_words)


''' 20. Write a Python program to remove specific words from the given list. 
    Data:
        Original list:
        list:['red', 'green', 'blue', 'white', 'black', 'orange']
    Expected Output:
        Remove words:
        ['white', 'orange']

        After removing the specified words from the said list:
        ['red', 'green', 'blue', 'black'] '''

list1 = ['red', 'green', 'blue', 'white', 'black', 'orange']
remove_words = ['white', 'orange']

print("Remove words:")
print(remove_words)

filtered_list = []
for word in list1:
    if word not in remove_words:
        filtered_list.append(word)

print("\nAfter removing the specified words from the said list:")
print(filtered_list)
