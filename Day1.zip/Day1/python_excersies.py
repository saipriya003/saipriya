# write a program to add two  integers 10 , 20

# a = int(input("Enter a: "))
# b = int(input("Enter b: "))
# add = a + b
# print(add)

# Write a program to find the type of a, b ,c where a=2, b=2.8,c="John"
# a = 2
# b = 2.8
# c = "john"
# print(type(a))
# print(type(b))
# print(type(c))

# Write a program to swap the two numbers , where a=2 ,b=4 the program should print a= 4 ,b=2
# a = 2
# b = 4
# swap = a,b = b,a
# print(f"The value of a and b is {swap}")

# Write a program to swap the two numbers , using 3 variables
# a = int(input("Enter a: "))
# b = int(input("Enter b: "))
# temp = a
# a = b
# b = temp
# print(f"The value of a and b is {a} and {b}")

# Write a program to print the numerator and denominator , quotient and remainder

# numerator = int(input("Enter the numerator: "))
# denominator = int(input("Enter the denominator: "))
# quotient = numerator // denominator
# remainder = numerator % denominator
# print(f"The numerator is {numerator}")
# print(f"The denominator is {denominator}")
# print(f"The quotient is {quotient}")
# print(f"The remainder is {remainder}")


# Write a program to convert Celcius to Fariehiet , fariienhiet=1.8*celcius+32
# celsius = float(input("Enter the celsius: "))
# Fah = 1.8 * celsius + 32
# print(f"The Fahrenheit is {Fah}")


# Write a program to find whether given number is odd or even
# number = int(input("Enter the number: "))
# if number % 2 == 0:
#     print("Even")
# else:
#     print("Odd")


# Write a program to check whether the person can vote or not
# age = int(input("Enter the age: "))
# if age >= 18:
#     print("Yes the person can vote")
# else:
#     print("No they are not eligible to vote")


# # Write a program to find whether the given year is leap year or not ?
# year = int(input("Enter the year: "))
# if(year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
#     print(f"{year} is a leap year")
# else:
#     print(f"{year} is not a leap year")

# Write a program to find the biggest of three numbers
n1 = int(input(f"Enter n1: "))
n2 = int(input(f"Enter n2: "))
n3 = int(input(f"Enter n3: "))
if n1 >= n2 and n1 >= n3:
    largest = n1
elif n2 >= n1 and n2 >= n3:
    largest = n2
else:
    largest = n3
print(f"The largest number is {largest}")












