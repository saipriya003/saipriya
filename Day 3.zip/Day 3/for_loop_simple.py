''' 1. Write a Python program to print expected output from the data given below.
    Data:
         country = ["India", "Canada", "Sweden"]
    Expected Output:
    India
    Canada
    Sweden '''
#
# country = ["India", "Canada", "Sweden"]
# for countries in country:
#     print(countries)

''' 2. Write a Python program to print expected output from the data given below. 
    Data:
         string = "banana"
    Expected Output: 
    b
    a
    n
    a
    n
    a '''
# string = "banana"
# for i in string:
#     print(i)


''' 3. Write a Python program to print expected output using break statement from the data given below.    
    Data:
        country = ["India", "Canada", "Sweden"]      
    Expected Output: 
    India
    Canada '''

# country = ["India", "Canada", "Sweden"]
# for countries in country:
#     if countries == "Sweden":
#         break
#     else:
#         print(countries)

''' 4. Write a Python program to print expected output using continue statement from the data given below.
    Data:
        country = ["India", "Canada", "Sweden"]
    Expected Output: 
    India
    Sweden '''

# country = ["India", "Canada", "Sweden"]
# for countries in country:
#     if countries == "Canada":
#         continue
#     else:
#         print(countries)

''' 6. Write a Python program to print expected output using range in for loop.
    Expected Output:
    0
    1
    2
    3
    4
    5 '''

# for i in range(0,6):
#     print(i)

''' 7. Write a Python program to print expected output by passing range parameters as (2, 6).
    Expected Output:
    2
    3
    4
    5 '''
# for i in range(2,6):
#     print(i)

'''8. Write a Python program to print expected output, range between 2 to 30 and increment the sequence by 3.
    Expected Output:
    2
    5
    8
    11
    14
    17
    20
    23
    26
    29 '''

# for i in range(2,31,3):
#     print(i)

''' 9. Write a Python program to print all numbers from 0 to 5, and print a message when the loop has ended.
    Expected Output:
    0
    1
    2
    3
    4
    5
    Finally finished! '''

# for i in range(0,6):
#     print(i)
# print("Finally finished!")

''' 10. Write a Python program to print each adjective for every fruits using nested for loop from the data given below.
    Data:
        adjective = ["red", "big", "tasty"]
        fruits = ["apple", "banana", "cherry"]
    Expected Output:
        red apple
        red banana
        red cherry
        big apple
        big banana
        big cherry
        tasty apple
        tasty banana
        tasty cherry '''
# adjective = ["red", "big", "tasty"]
# fruits = ["apple", "banana", "cherry"]
#
# for i in adjective:
#     for j in fruits:
#         print(i,j)

''' 11. Write a Python program to convert list of tuples into dictionary using setdefault() method.
    Data:
        l = [("x", 1), ("x", 2), ("x", 3), ("y", 1), ("y", 2), ("z", 1)]
    Expected Output:
        {'x': [1, 2, 3], 'y': [1, 2], 'z': [1]} '''

# l = [("x", 1), ("x", 2), ("x", 3), ("y", 1), ("y", 2), ("z", 1)]
# my_dict = {}
# for key, value in l:
#     my_dict.setdefault(key,[]).append(value)
# print(my_dict)


''' 12. Write a Python program to print the count of no. of elements in a list until an element in a list is a tuple using isinstance() method.
    Data:
        x = [10,20,30,(10,20),40]
    Expected Output: 3 '''

# x = [10, 20, 30, (10, 20), 40]
# count = 0
# for element in x:
#     if isinstance(element,tuple):
#         break
#     count += 1
# print(count)


''' 13. Write a Python program to access the index of elements in a list. 
    Data:
        x = [5, 15, 35, 8, 98]
    Expected Output:
        0 5
        1 15
        2 35
        3 8
        4 98 '''
#
# x = [5, 15, 35, 8, 98]
# for index,element in enumerate(x):
#     print(f"{index} {element}")

''' 14. Write a Python program to create multiple lists.
    Expected output:
        {'1': [], '2': [], '3': [], '4': [], '5': [], '6': [], '7': [], '8': [], '9': [], '10': []} '''


# data = {
#     '1' : [],
#     '2' : [],
#     '3' : [],
#     '4' : [],
#     '5' : [],
#     '6' : [],
#     '7' : [],
#     '8' : [],
#     '9' : [],
#     '10' : []
# }
# print(data)


''' 15. Write a Python program to create a list of empty dictionaries.
    Data:
        n = 5
    Expected Output:
        [{}, {}, {}, {}, {}] '''

# n = int(input("Enter how many empty dictionaries you want: "))
# empty_dict_list = [{} for _ in range(n)]
# print(empty_dict_list)


''' 16. Write a Python program to iterate over two lists simultaneously.
    Data:
        x = [1, 2, 3]
        name = ['boss', 'sai', 'bala']
    Expected Output:
        1 boss
        2 sai
        3 bala '''

# x = [1, 2, 3]
# name = ['boss', 'sai', 'bala']
# for x,name in zip(x,name):
#     print(x,name)


''' 17. Write a Python program print all elements of the list using for loop and range().
    Data:
        name = ['boss', 'sai', 'bala']
    Expected Output:
        boss
        sai
        bala '''

# name = ['boss', 'sai', 'bala']
# for i in range(len(name)): # creates a sequence of indicies: 0,1,2,3
#     print(name[i]) # accesses the element of each index


# 18. Write a Python program to print without newline or space.
# for char in "hello":
#     print(char, end="")


''' 19. Write a Python program to print expected output using enumerate() from the data given below.
    Data:
        x = ["suresh", "boss", "siva", "bala", "sai", "balu", "karthi"] 
    Expected Output:
        President 1: suresh
        President 2: boss
        President 3: siva
        President 4: bala
        President 5: sai
        President 6: balu
        President 7: karthi '''

# x = ["suresh", "boss", "siva", "bala", "sai", "balu", "karthi"]
# for index, elements in enumerate(x):
#     print(f"President {index}: {elements}")


''' 20. Write a Python program to print expected output using enumerate() from the data given below.
    Data:
        name = ["suresh", "boss", "siva", "bala"]
        ratios = [0.2, 0.3, 0.1, 0.4]
    Expected Output:
        20.0% suresh
        30.0% boss
        50.0% siva
        40.0% bala '''

# name = ["suresh", "boss", "siva", "bala"]
# ratios = [0.2, 0.3, 0.1, 0.4]
# for i , persons in enumerate(name):
#     print(f"{ratios[i] * 100:.1f}% {persons}")









