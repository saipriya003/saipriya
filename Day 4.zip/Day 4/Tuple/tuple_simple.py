''' 1. Write a Python program to print convert a list into a tuple.
    Data:
        x = [1,2]
    Expected Output:
        x - [1, 2]
        <class 'list'>
        y - (1, 2)
        <class 'tuple'> '''
from itertools import count

# x = [1,2]
# print(type(x))
# y = tuple(x)
# print(y)
# print(type(y))

'''2. Write a Python program to create a tuple with different data types.
    Data:
        x = ("tuples",3.2, 1)
    Expected Output:
        ('tuples', 3.2, 1)'''

# x = ("tuples", 3.2, 1)
# print(x)


'''3. Write a Python program to create a tuple with numbers and print the items one by one.
    Data:
        x = 5, 10, 15, 20, 25
    Expected Output:
        <class 'tuple'> 
        (5, 10, 15, 20, 25)
        5
        10
        15
        20
        25'''
# x = (5, 10, 15, 20, 25)
# print(type(x))
# for i in x:
#     print(i)

'''4. Write a Python program to convert a tuple of characters into a string.
    Data:
        x = ('v', 'o', 'l', 'a', 't', 'a', 'l', 'i', 't', 'y')
    Expected Output:
        volatility'''

# x = ('v', 'o', 'l', 'a', 't', 'a', 'l', 'i', 't', 'y')
# res = ''.join(x)
# print(res)

'''5. Write a Python program to convert a tuple into a list.
    Data:
        x=(1,2,3)
    Expected Output:
        (1, 2, 3)
        [1, 2, 3]'''

# x=(1,2,3)
# print(x)
# my_list = list(x)
# print(my_list)

'''6. Write a Python program to remove an element from a tuple.
    Data:
        x = ("a","b","c","d")
    Expected Output:
        ('a', 'b', 'd')'''

x = ("a","b","c","d")


'''7. Write a Python program to find the length of a tuple.
    Data:
        x = ("positions")
    Expected Output:
        ('p', 'o', 's', 'i', 't', 'i', 'o', 'n', 's')
        9'''

# x = ("positions")
# tuple_data = tuple(x)
# print(tuple_data)
# length = len(tuple_data)
# print(length)


'''8. Write a Python program to convert a tuple into a dictionary.
    Data:
        x = ((2, "w"),(3, "r"))
    Expected Output:
        {'w': 2, 'r': 3}'''

# x = ((2, "w"), (3, "r"))
# res = {value: key for key,value in x} #swap key and value
# print(res)

'''9. Write a Python program to reverse the tuple elements.
    Data:
        x = ("Baskar")
        x = (5, 10, 15, 20)
    Expected Output:
        ('r', 'a', 'k', 's', 'a', 'B')
        (20, 15, 10, 5)'''

# x = "Baskar"
# y = (5, 10, 15, 20)
# reversed_tuple = tuple(x[::-1]) # converts the string into tuple of characters.
# reversed_tuple1 = y[::-1]
# print(reversed_tuple)
# print(reversed_tuple1)


'''10. Write a Python program to unpack a tuple in several variables.  
    Data:
        x = 4, 8, 3
    Expected Output:
        (4, 8, 3)
        15'''

# x = 4, 8, 3
# print(x)
# print(sum(x))

'''11. Write a Python program to create a nested tuple.
    Data:
        x = ("Boss", [8, 4, 6], (1, 2, 3)) 
    Expected Output:
        ('Boss', [8, 4, 6], (1, 2, 3))'''

'''12. Write a Python program to convert a string into a tuple.
    Data:
        x = ("hello")
    Expected Output:
        <class 'str'>
        <class 'tuple'>'''

# x = ("hello")
# print(type(x))
# tuple_data = tuple(x)
# print(type(tuple_data))

'''13. Write a Python program to access tuple elements using index.
    Data:
        x = ('B','a','s','k','a','r')
    Expected Output:
        x[0] is : B
        x[5] is : r'''

# x = ('B', 'a', 's', 'k', 'a', 'r')
# print("x[0] is :",x[0])
# print("x[5] is :",x[5])

'''14. Write a Python program to access nested tuple elements using index. 
    Data:
        x = ("Boss", [8, 4, 6], (1, 2, 3)) 
    Expected Output:
        x[0][3] is : s
        x[1][1] is : 4'''

# x = ("Boss", [8, 4, 6], (1, 2, 3))
# print("x[0][3] is :",x[0][3])
# print("x[1][1] is :",x[1][1])


'''15. Write a Python program to access tuple elements using negative index.
    Data:
        x = ('B','a','s','k','a','r')
    Expected Output:
        x[-1] is : r
        x[-6] is : B'''

# x = ('B','a','s','k','a','r')
# print("x[-1] is :",x[-1])
# print("x[-6] is :",x[-6])


# index = int(input("Enter the index: "))
# if -1 <= index < len(x):
#     print(f"x[{index}] is : {x[index]}")



'''16. Write a Python program to use + and * operators in a tuple and print the results in tuple.
    Data:
        x : (1, 12, 123)
        y : (4, 9)    
    Expected Output:
        z = x + y : (1, 12, 123, 4, 9)
        z * 3 : (1, 12, 123, 4, 9, 1, 12, 123, 4, 9, 1, 12, 123, 4, 9)'''

# x= (1, 12, 123)
# y= (4, 9)
# z = x+y
# next = z * 3
# print(f"z = x + y : {z}")
# print(f"z * 3 : {next}")


'''17. Write a Python program to print each elements of a tuple using for loop.
    Data:
        Tuple x = ('boss','sai')
    Expected Output:
        Hello boss
        Hello sai'''

# Tuple_x = ('boss','sai')
# print(f"Hello {Tuple_x[0]} ")
# print(f"Hello {Tuple_x[1]} ")


'''18. Write a Python program to print the count of 'p' and the index of 'l' from the given tuple using tuple methods.
    Data: 
        x = ('a', 'p', 'p', 'l', 'e')
    Expected Output:
        Count of p is : 2
        Index of l is : 3'''

# my_tuple = ('a', 'p', 'p', 'l', 'e')
# p_count = my_tuple.count("p")
# l_index = my_tuple.index("l")
# print("Count of p is :",p_count)
# print("Index of l is :",l_index)


'''19. Write a Python program to update an element of a given tuple from 7 to 77.
    Data:
        x = (1, [9, 8, 7], "boss")
    Expected Output:
        (1, [9, 8, 7], 'boss')
        (1, [9, 8, 77], 'boss')'''

# x = (1, [9, 8, 7], "boss")
# print(x)
# for i in range(len(x[1])):
#     if x[1][i] == 7:
#         x[1][i] = 77
# print(x)


'''20. Write a Python program to slice a tuple.
    Data: 
        x = (11, 22, 33, 44, 55, 66, 77, 88, 99)
    Expected Output:
        (11, 22, 33, 44, 55, 66, 77, 88, 99)
        (33, 44, 55)
        (11, 22, 33, 44)
        (55, 66, 77, 88, 99)
        (55, 66, 77, 88)
        (11, 22, 33, 44, 55, 66, 77, 88, 99)'''

# x = (11, 22, 33, 44, 55, 66, 77, 88, 99)
# print(x)
# print(x[2:5])
# print(x[:4])
# print(x[4:])
# print(x[4:8])
# print(x)
