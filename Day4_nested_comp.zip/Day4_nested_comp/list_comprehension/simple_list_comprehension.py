# 1.
# s = "constituition"
# result = [char for char in s]
# print(result)


# 2.
# even_numbers = [x for x in range(21) if x % 2 == 0]
# print(even_numbers)


# 3.
# numbers = [x for x in range(101) if x % 2 == 0 or x % 5 == 0]
# print(numbers)
# numbers = [x for x in range(101) if x % 10 == 0]
# print(numbers)

# 4.
# array_3d = [[["*" for _ in range(9)] for _ in range(6)] for _ in range(3)]
# print(array_3d)


# 5.
# m = [7, 8, 120, 25, 44, 20, 27]
# odd_numbers = [x for x in m if x % 2 != 0]
# print(odd_numbers)


# 6.
# lst = ['l', 'm']
# n = 4
# result = [f"{ch}{i}" for i in range(1, n+1) for ch in lst]
# print(result)


# 7.
# x = ['marvel', 'boss', 'siva']
# result = [elem for item in x for elem in ('c', item)]
# print(result)



# 8.
# x = [['Red'], ['Green'], ['Black']]
# for item in x:
#     print(item)


# 9.
# lst = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n']
# result = [lst[i::3] for i in range(3)]
# print(result)


# 10.
# def check_all_equal(lst, string):
#     return all(x == string for x in lst)
#
# x = ["green", "orange", "black", "white"]
# y = ["green", "green", "green", "green"]
#
# print(check_all_equal(x, "green"))
# print(check_all_equal(y, "green"))


# 11.
# x = [(4, 1), (1, 2), (6, 0)]
# min_tuple = min(x, key=lambda t: t[1])
# print(min_tuple)


# 12.
# n = 5
# result = [{} for _ in range(n)]
# print(result)


# 13.
# lst = [1, 2, 3, 4]
# string = "boss"
# result = [string + str(x) for x in lst]
# print(result)

# 14.
# a = [220, 330, 500]
# print(all(x > 200 for x in a))


# 15.
# x = [{}, {}, {}]
# y = [{1, 2}, {}, {}]
#
# print(all(not d for d in x))
# print(all(not d for d in y))

# 16.
# lst = ['baskar', 'bala', 'siva', 'sai', 'suresh', 'kumar']
# result = [lst[i] for i in range(len(lst)) if i not in (0, 4, 5)]
# print(result)
#

# 17.
# result = ['Even' if i % 2 == 0 else 'Odd' for i in range(10)]
# print(result)

# 18.
# x = [[1, 2], [3, 4], [5, 6], [7, 8]]
# first_elements = [item[0] for item in x]
# second_elements = [item[1] for item in x]
# print([first_elements, second_elements])


19.
a = [-2, -1, 0, 1, 2, 3]
b = [4, 5, 6, 7, 8]

a_pos = [x for x in a if x > 0]
b_even = [b[i] for i in range(len(b)) if i % 2 == 0]  

result = [x * y for x in a_pos for y in b_even]

print(result)




# 20.
# l = [1, 2, 3, 4, 5]
# result = ['yes' if x == 1 else 'no' if x == 2 else 'idle' for x in l]
# print(result)


