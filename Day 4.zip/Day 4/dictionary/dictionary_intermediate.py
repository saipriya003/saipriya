#1Q:
# d = {1:2, 3:4, 4:3, 2:1, 0:0}
# asc = dict(sorted(d.items(), key=lambda item: item[1]))
# desc = dict(sorted(d.items(), key=lambda item: item[1], reverse=True))
# print("Ascending:", asc)
# print("Descending:", desc)


#2Q:
# d = {1: 10, 2: 20, 3: 30, 4: 40, 5: 50, 6: 60}
# for k in [5, 7, 6]:
#     if k in d:
#         print(f"key {k} is present in the Dictionary")
#     else:
#         print(f"key {k} is not present in the Dictionary")


#3Q:
# class MyClass:
#     def __init__(self):
#         self.x = 'boss'
#         self.y = 'siva'
#         self.z = 'suresh'
#
# obj = MyClass()
# print(obj.__dict__)


#4Q:
# D = [{"V":"S001"}, {"V": "S002"}, {"VI": "S001"}, {"VI": "S005"},
#      {"VII":"S005"}, {"V":"S009"},{"VIII":"S007"}]
# unique_values = set()
# for dic in D:
#     unique_values.update(dic.values())
# print(unique_values)


#5Q:
# from collections import Counter
#
# l = [{'subject': 'chemistry', 'mark': 97},
#      {'subject': 'social', 'mark': 89},
#      {'subject': 'chemistry', 'mark': 73}]
# result = Counter()
# for i in l:
#     result[i['subject']] += i['mark']
# print(result)


#6Q:
# s = "Kaziranga"
# result = {char: s.count(char) for char in s}
# print(result)


#7Q:
# student = [{'id': 7, 'success': True, 'name': 'Rahman'},
#            {'id': 8, 'success': False, 'name': 'Harris'},
#            {'id': 4, 'success': True, 'name': 'Aniruth'}]
#
# id_sum = sum(s['id'] for s in student)
# success_sum = sum(s['success'] for s in student)
# print("Sum of id:", id_sum)
# print("Sum of success:", success_sum)



#8Q:
# student = {'S  001': ['Math', 'Science'], 'S    002': ['Math', 'English']}
# cleaned = {k.replace(" ", ""): v for k, v in student.items()}
# print(cleaned)



#9Q:
# items = {'Wallet': 45.50, 'Keychain':35, 'Perfume': 41.30, 'Sanitizer':55, 'Knife': 24}
# top_items = sorted(items.items(), key=lambda x: x[1], reverse=True)[:3]
# for k, v in top_items:
#     print(k, v)


#10Q:
# d = {1:10,2:20,3:30,4:40,5:50,6:60}
# print("key  value  count")
# for count, (k, v) in enumerate(d.items(), start=1):
#     print(f"{k}     {v}     {count}")


#11Q:
# students = {"Arun":{"class":"A", "roll_no":2},
#             "Tharun": {"class":"A", "roll_no":1},
#             "Varun":{"class":"B", "roll_no":3}}
#
# for name, info in students.items():
#     print(name)
#     for k, v in info.items():
#         print(f"{k} : {v}")
#     print("***********")


#12Q:
# student = {'name': 'Boss', 'class': 'V', 'roll id': '2'}
#
# def check_keys(keys, d):
#     return all(k in d for k in keys)
#
# print(check_keys(['name', 'class'], student))  # True
# print(check_keys(['name', 'section'], student))  # False
# print(check_keys(['roll id'], student))  # True


#13Q:
# d = {'Boss': ['subj1', 'subj2', 'subj3'], 'Siva': ['subj1', 'subj2']}
# count = sum(len(v) for v in d.values())
# print(count)


#14Q:
# from collections import Counter
#
# d = {'Math':91, 'Physics':93, 'Chemistry':97}
# sorted_items = sorted(Counter(d).items(), key=lambda x: x[1], reverse=True)
# print(sorted_items)


#15Q:
# x = {"key1":1, "key2":3, "key3":2}
# y = {"key1":1, "key2":2}
# for k in x:
#     if k in y and x[k] == y[k]:
#         print(f"{k}: {x[k]} is present in both x and y")



#16Q:
# d = {'c1': 'Red', 'c2': 'Green', 'c3': None}
# filtered = {k: v for k, v in d.items() if v is not None}
# print(filtered)


#17Q:
# marks = {'Cierra Vega': 175, 'Alden Cantrell': 180, 'Kierra Gentry': 165, 'Pierre Cox': 190}
# filtered = {k: v for k, v in marks.items() if v > 170}
# print(filtered)


#18Q:
# name = [('boss', 1), ('bala', 2), ('siva', 3), ('karthi', 4), ('suresh', 1)]
# d = {}
# for k, v in name:
#     d.setdefault(k, []).append(v)
# print(d)


#19Q:
# d = {'D1': [10, 20, 30], 'D2': [20, 30, 40], 'D3': [12, 34]}
# cleared = {k: [] for k in d}
# print(cleared)


#20Q:
d = {'Maths': [88, 89, 90], 'Physics': [92, 94, 89], 'Chemistry': [90, 87, 93]}
d['Maths'] = [x + 1 for x in d['Maths']]
print(d)
