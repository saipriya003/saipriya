#1Q:
# d1 = {'x':500, 'y':5874, 'z': 560}
# print("Maximum Value: ", max(d1.values()))
# print("Minimum Value: ", min(d1.values()))


#2Q:
import json

# student_data = {
#  'id1': {'name': ['Boss'], 'class': ['V'], 'subject_integration': ['english, math, science']},
#  'id2': {'name': ['Suresh'], 'class': ['V'], 'subject_integration': ['english, math, science']},
#  'id3': {'name': ['Siva'], 'class': ['V'], 'subject_integration': ['english, math, science']},
#  'id4': {'name': ['Surya'], 'class': ['V'], 'subject_integration': ['english, math, science']}
# }
# print(student_data)


#3Q:
# from collections import defaultdict
#
# classes = ['Class-V', 'Class-VI', 'Class-VII', 'Class-VIII']
# numbers = [1, 2, 2, 3]
#
# d = defaultdict(set)
# for k, v in zip(classes, numbers):
#     d[k].add(v)
# print(d)


#4Q:
# student = [
#     {'id': 1, 'subject': 'math', 'V': 70, 'VI': 82},
#     {'id': 2, 'subject': 'math', 'V': 73, 'VI': 74},
#     {'id': 3, 'subject': 'math', 'V': 75, 'VI': 86}
# ]
#
# result = []
# for s in student:
#     avg = (s['V'] + s['VI']) / 2
#     result.append({'id': s['id'], 'subject': s['subject'], 'V+VI': avg})
# print(result)



#5Q:
# import json
#
# d = {
#     'students': [{'firstName': 'Boss', 'lastName': 'King'},
#                  {'firstName': 'Siva', 'lastName': 'Raj'},
#                  {'firstName': 'suresh', 'lastName': 'kumar'}],
#     'teachers': [{'firstName': 'Kumar', 'lastName': 'Samy'},
#                  {'firstName': 'Dinesh', 'lastName': 'Kumar'}]
# }
#
# with open("data.json", "w") as f:
#     json.dump(d, f, indent=4)
#
# with open("data.json") as f:
#     print(json.load(f))



#6Q:
# student_id = ["R1", "R2", "R3", "R4"]
# student_name = ["Saravana", "Shreya", "Shakthi", "Shwetha"]
# student_grade = [85, 98, 89, 92]
#
# nested = [{id_: {name: grade}} for id_, name, grade in zip(student_id, student_name, student_grade)]
# print("Nested dictionary:")
# print(nested)


#7Q:
# data = {'Varun': (6.2, 70), 'Tharun': (5.9, 60), 'Arun': (6.0, 68), 'Suran': (5.8, 66)}
# result = {k: v for k, v in data.items() if v[0] > 5.5 and v[1] > 65}
# print("Filtered:", result)


#8Q:
# data = {'dinesh': 12, 'boss': 12, 'siva': 12, 'suresh': 12}
# print("Check all are 12 in the dictionary.")
# print(all(v == 12 for v in data.values()))
#
# print("Check all are 10 in the dictionary.")
# print(all(v == 10 for v in data.values()))


#9Q:
# data = [{'Math': 90, 'Science': 92}, {'Math': 89, 'Science': 94}, {'Math': 92, 'Science': 88}]
# math_scores = [d['Math'] for d in data]
# print("Math scores:", math_scores)


#10Q:
# color = {1 : 'red', 2 : 'green', 3 : 'black', 4 : 'white', 5 : 'black'}
# name = {'1' : 'Boss', '2' : 'Siva', '3' : 'Suresh', '4' : 'Kumar'}
#
# color_lengths = {v: len(v) for v in color.values()}
# name_lengths = {v: len(v) for v in name.values()}
# print(color_lengths)
# print(name_lengths)


#11Q:
# color = {1: 'red', 2: 'green', 3: 'black', 4: 'white', 5: 'black'}
# name = {'1': 'Boss', '2': 'Siva', '3': 'Suresh', '4': 'Kumar'}
#
# color_list = [[k, v] for k, v in color.items()]
# name_list = [[k, v] for k, v in name.items()]
# print("Convert the said dictionary into a list of lists:")
# print(color_list)
# print(name_list)


#12Q:
# students1 = {'V': [1, 4, 6, 10], 'VI': [1, 4, 12], 'VII': [1, 3, 8]}
# students2 = {'V': [1, 3, 5], 'VI': [1, 5], 'VII': [2, 7, 9]}
#
# def filter_even(d):
#     return {k: [v for v in vals if v % 2 == 0] for k, vals in d.items()}
#
# print(filter_even(students1))
# print(filter_even(students2))


#13Q:
# def top_n_keys(d, n):
#     return [k for k, v in sorted(d.items(), key=lambda item: item[1], reverse=True)[:n]]
#
# dictt = {'a':5, 'b':14, 'c': 32, 'd':35, 'e':24, 'f': 100, 'g':57, 'h':8, 'i': 100}
# print("Top 2 highest:", top_n_keys(dictt, 2))
# print("Top 5 highest:", top_n_keys(dictt, 5))


#14Q:
# data = {'V': [10, 12], 'VI': [10], 'VII': [10, 20, 30, 40], 'VIII': [20], 'IX': [10, 30, 50, 70], 'X': [80]}
# min_len = min(len(v) for v in data.values())
# shortest_keys = [k for k, v in data.items() if len(v) == min_len]
# print("Shortest list keys:", shortest_keys)


#15Q:
# from collections import Counter
#
# data = {'V': 10, 'VI': 10, 'VII': 40, 'VIII': 20, 'IX': 70, 'X': 80, 'XI': 40, 'XII': 20}
# frequency = Counter(data.values())
# print(frequency)


#16Q:
# students = [
#     {'student_id': 1, 'name': 'Basakr', 'class': 'V'},
#     {'student_id': 2, 'name': 'Suresh', 'class': 'V'},
#     {'student_id': 3, 'name': 'Siva', 'class': 'VI'},
#     {'student_id': 4, 'name': 'Karthi', 'class': 'VI'},
#     {'student_id': 5, 'name': 'Dinesh', 'class': 'VII'}
# ]
#
# all_data = [[s['student_id'], s['name'], s['class']] for s in students]
# id_name = [[s['student_id'], s['name']] for s in students]
# name_class = [[s['name'], s['class']] for s in students]
#
# print(all_data)
# print(id_name)
# print(name_class)



#17Q:
# students = [[1, 'Basakr', 'V'], [2, 'Suresh', 'V'], [3, 'Siva', 'VI'], [4, 'Karthi', 'VI'], [5, 'Dinesh', 'VII']]
# result = {s[0]: s[1:] for s in students}
# print(result)


#18Q:
# name = {'#FF0000': 'Boss', '#800000': 'Siva', '#FFFF00': 'Kumar', '#808000': 'Suresh'}
#
# total_length = sum(len(v) for v in name.values())
# print("Total length of all values of the said dictionary:", total_length)


#19Q:
# students = [
#     {'student_id': 1, 'name': 'Basakr', 'class': 'V'},
#     {'student_id': 2, 'name': 'Suresh', 'class': 'V'},
#     {'student_id': 3, 'name': 'Siva', 'class': 'VI'},
#     {'student_id': 4, 'name': 'Karthi', 'class': 'VI'},
#     {'student_id': 5, 'name': 'Dinesh', 'class': 'VII'}
# ]
#
# students = [
#     {'student_id': 1, 'name': 'Basakr', 'class': 'V'},
#     {'student_id': 2, 'name': 'Suresh', 'class': 'V'},
#     {'student_id': 3, 'name': 'Siva', 'class': 'VI'},
#     {'student_id': 4, 'name': 'Karthi', 'class': 'VI'},
#     {'student_id': 5, 'name': 'Dinesh', 'class': 'VII'}
# ]
#
# def check_key_value_exist(data, key, value):
#     return any(d.get(key) == value for d in data)
#
# print("Check if a specific Key and a value exist in the said dictionary:")
# print(check_key_value_exist(students, 'name', 'Suresh'))   # True
# print(check_key_value_exist(students, 'name', 'Raj'))      # False
# print(check_key_value_exist(students, 'class', 'VI'))      # True
# print(check_key_value_exist(students, 'class', 'VIII'))    # False
# print(check_key_value_exist(students, 'student_id', 10))   # False
# print(check_key_value_exist(students, 'name', 'Boss'))     # False


#20Q:
# def all_values_same(d, check_value):
#     return all(v == check_value for v in d.values())
#
# d = {'dinesh': 45, 'boss': 45, 'siva': 45, 'suresh': 45}
#
# print("Check all are  12 in the dictionary.")
# print(all_values_same(d, 12))
#
# print("Check all are  45 in the dictionary.")
# print(all_values_same(d, 45))
