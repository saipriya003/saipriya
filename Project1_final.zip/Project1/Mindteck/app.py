from flask import Flask, render_template, request, redirect, jsonify
from flask_restful import Api

from resource.user import User
from db import get_connection  # This must be the fixed version with comma before cursorclass

app = Flask(__name__)
api = Api(app)

api.add_resource(User, '/api/users')

@app.route("/")
def home():
    return render_template("base.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/service")
def service():
    return render_template("service.html")

@app.route("/technology")
def technology():
    return render_template("technology.html")

@app.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        # Get form data
        name = request.form.get("name")
        email = request.form.get("email")
        phone = request.form.get("phone")
        message = request.form.get("message")

        try:
            conn = get_connection()
            with conn.cursor() as cursor:
                sql = "INSERT INTO contacts (name, email, phone, message) VALUES (%s, %s, %s, %s)"
                cursor.execute(sql, (name, email, phone, message))
                conn.commit()
        except Exception as e:
            return f"Error: {e}"
        finally:
            conn.close()

        return redirect("/contact")  # Avoid form re-submission

    return render_template("contact.html")

if __name__ == "__main__":
    app.run(debug=True)
