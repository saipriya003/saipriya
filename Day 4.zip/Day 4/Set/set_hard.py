#1Q:
# x = 'Python'
# y = ('a', 'e', 'i', 'o', 'u')
# z = ['a', 'e', 'i', 'o', 'u']
# a = range(5)
#
# print(set())
# print(set(x))
# print(set(y))
# print(set(z))
# print(set(a))



#2Q:
# x = {'a', 'e', 'i', 'o', 'u'}
# y = {'a':1, 'e': 2, 'i':3, 'o':4, 'u':5}
# z = ('a', 'e', 'i', 'o', 'u')
#
# print(set(x))               # Already a set
# print(set(y))               # Set from dictionary keys
# print(frozenset(z))         # Frozen set from tuple



# #3Q:
# def has_duplicates(lst):
#     return len(lst) != len(set(lst))
#
# x = [21, 13, 35, 31, 12, 35, 10, 9, 9]
# y = [1, 2, 3, 4]
#
# print(has_duplicates(x))
# print(has_duplicates(y))



#4Q:
# x = [3, 5, 7, 10, 9]
# y = [7, 11, 2, 17, 5]
#
# result = list(set(x) & set(y))
# print(result)


#5Q:
# def one_row_words(words):
#     rows = [
#         set("qwertyuiopQWERTYUIOP"),
#         set("asdfghjklASDFGHJKL"),
#         set("zxcvbnmZXCVBNM")
#     ]
#     result = []
#     for word in words:
#         for row in rows:
#             if set(word).issubset(row):
#                 result.append(word)
#                 break
#     return result
#
# words = ['Router', 'Type', 'Pine', 'Dash', 'Top', 'Rower', 'Freedom']
# print(one_row_words(words))


#6Q:
# x = [["netflix","google","facebook"],["netflix","amazon"],["facebook","google"]]
# result = [i for i, sub in enumerate(x) if "netflix" in sub]
# print(result)


#7Q:
# language = {'English', 'French', 'German'}
# vowels = {'a', 'e', 'i', 'u'}
# language.remove('German')
# print("After remove:", language)
#
# vowels.add('o')
# print("Add:", vowels)
# v_copy = vowels.copy()
# print("Copy:", v_copy)
#
# print("Vowels (before clear):", vowels)
# vowels.clear()
# print("Vowels (after clear):", vowels)


#8Q:
# A = {'a', 'b', 'c', 'd'}
# B = {'c', 'f', 'g'}
# numbers = {2, 3, 4, 5}
# print("Difference:", A.difference(B))
# A.difference_update(B)
# print("Difference_update:", A)
# numbers.discard(3)
# print("After discard:", numbers)



#9Q:
# A = {2, 3, 5, 4}
# B = {2, 5, 4, 100}
# C = {3, 8, 9, 10}
#
# print("intersection:", A.intersection(B))
# print("intersection with C:", A.intersection(C))
#
# A.intersection_update(B)
# print("intersection_update:", A)
#
# print("Are A and B disjoint?", A.isdisjoint(B))
# print("Are B and C disjoint?", B.isdisjoint(C))



#10:
A = {1, 2, 3}
B = {1, 2, 4}
C = {1, 2, 4, 6}

print("A issubset of B:", A.issubset(B))
print("B issubset of A:", B.issubset(A))

popped = A.pop()
print("Element popped from A:", popped)
print("After pop A:", A)

print("A U B =", A.union(B))
print("A U B U C =", A.union(B, C))
