#1. Double each item in list
# comp = [1, 4, 9, 16]
# doubled = [2 * x for x in comp]
# print(doubled)


#2. Cumulative sum using list comprehension
# x = [1, 4, 9, 16]
# cumsum = [sum(x[:i+1]) for i in range(len(x))]
# print(cumsum)


#3. Squares of odd numbers from 1 to 10
# squares_odd = [i**2 for i in range(1, 11) if i % 2 != 0]
# print(squares_odd)


#4. Powers of 2 from 1 to 8
# powers_of_2 = [2**i for i in range(1, 9)]
# print(powers_of_2)


#5. Prime numbers from 1 to 50
# def is_prime(n):
#     if n < 2:
#         return False
#     for i in range(2, int(n**0.5) + 1):
#         if n % i == 0:
#             return False
#     return True
#
# primes = [i for i in range(1, 51) if is_prime(i)]
# print(primes)

# 6. Multiplication table of 5 up to 10 using list comprehension
# table = [[5, i, 5*i] for i in range(1, 11)]
# print("Multiplication Table")
# for row in table:
#     print(row)

#7. Create matrix as specified
# matrixs = [[i for i in range(5)] for _ in range(5)]
# print(matrixs)


#8. Flatten a 2D list
# matrixs = [[1, 7, 3], [4, 9, 6], [7, 10, 9]]
# flattened = [item for sublist in matrixs for item in sublist]
# print(flattened)

#9. Items with length < 6 from nested list
# lists = [['Mars', 'Jupiter', 'Saturn'], ['Mercury', 'Venus', 'Earth'], ['Uranus', 'Neptune', 'Pluto']]
# filtered = [item for sublist in lists for item in sublist if len(item) < 6]
# print(filtered)

#10. List of all even numbers up to 10**7 (Warning: very large!)
# import time
#
# start = time.time()
# evens = list(range(2, 10**7 + 1, 2))
# end = time.time()
# print(f"Execution time = {end - start}")


#11. Difference between Generator Expressions and List Comprehensions
# import sys
# data = range(10000)
# comprehension = [x * 2 for x in data]
# print("Comprehensions =", sys.getsizeof(comprehension))
# generator = (x * 2 for x in data)
# print("Generator =", sys.getsizeof(generator))


#12. Insert string at beginning of each item in list
# lists = [1, 2, 3, 4, 5, 6, 4, 3, 5, 67, 8, 9]
# string = "sun"
# new_list = [string + str(i) for i in lists]
# print(new_list)



#13. Transpose of matrix using list comprehension
# x = [[14, 22], [33, 44], [55, 61], [17, 81]]
# transpose = [[row[i] for row in x] for i in range(len(x[0]))]
# print(transpose)

#15. Tuple with smallest second element
# x = [(10, 14), (12, 22), (66, 10)]
# min_tuple = min(x, key=lambda t: t[1])
# print(min_tuple)

# 16. Print all numbers except even ones
# A = [77, 88, 120, 25, 44, 20, 27]
# odds = [i for i in A if i % 2 != 0]
# print(odds)

#17. Cumulative product using list comprehension
# nums = [1, 2, 3, 4, 5]
# cumulative_product = [1]
# for i in range(1, len(nums)):
#     cumulative_product.append(cumulative_product[-1] * nums[i])
# cumulative_product[0] = nums[0]
# print(cumulative_product)


#18. Even numbers in a list
# x = [2, 433, 65, 8, 12, 9, 7, 56, 8, 4]
# evens = [i for i in x if i % 2 == 0]
# print("Even numbers in the list: ", evens)

#19. Create matrix with range(5) repeated 6 times
# matrixs = [[i for i in range(5)] for _ in range(6)]
# print(matrixs)

#20. Flatten a list of lists
matrixs = [[0, 0, 0], [1, 1, 1], [2, 2, 2], [3, 3, 3]]
flattened = [item for sublist in matrixs for item in sublist]
print(flattened)  # [0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3]
